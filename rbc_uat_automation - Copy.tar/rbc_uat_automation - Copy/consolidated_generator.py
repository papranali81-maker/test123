import re
import shutil
import tarfile
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple, Dict

import pandas as pd
import streamlit as st
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Side

from utility import _ensure_dirs, _recent_files, _validate_ccms_filename, _validate_cms_filename, \
    _validate_cnb_filename, _save_uploaded



# ==========================================================
# Base directory (works even if you run from elsewhere)
# ==========================================================

ROOT = Path(__file__).resolve().parent
DATA_ROOT = ROOT / 'data' / 'consolidated_generator'
UPLOADED_CC = DATA_ROOT / 'Uploaded_files' / 'ccms'
UPLOADED_CMS = DATA_ROOT / 'Uploaded_files' / 'cms'
UPLOADED_CNB = DATA_ROOT / 'Uploaded_files' / 'cnb'
EXTRACTED = DATA_ROOT / 'Extracted_psv_files'
EXTRACTED.mkdir(parents=True, exist_ok=True)
EXTRACTED_CC = DATA_ROOT / 'Extracted_psv_files'/ 'ccms'
EXTRACTED_CMS = DATA_ROOT / 'Extracted_psv_files'/ 'cms'
EXTRACTED_CNB = DATA_ROOT / 'Extracted_psv_files'/ 'cnb'
REPORTS_ROOT = ROOT / 'reports' / 'consolidated_generator'
REPORTS_ROOT.mkdir(parents=True, exist_ok=True)
REPORTS_CC = REPORTS_ROOT / 'ccms'
REPORTS_CC.mkdir(parents=True, exist_ok=True)
REPORTS_CMS = REPORTS_ROOT / 'cms'
REPORTS_CMS.mkdir(parents=True, exist_ok=True)
REPORTS_CNB = REPORTS_ROOT / 'cnb'
REPORTS_CNB.mkdir(parents=True, exist_ok=True)

###############################################################################

# --- New helper imports from regression_generator to reuse PSV readers and helpers ---
try:
    from regression_generator import _find_inner_out_tar, read_psv_preserve_shape, _read_psv_skip_meta, read_facility_psv_smart
except Exception:
    # graceful fallback if import fails in some contexts; we'll implement simple readers below if needed
    _find_inner_out_tar = None


# --- New helper: map module -> extracted folder ---
_module_to_extracted = {
    'ccms': EXTRACTED_CC,
    'cms': EXTRACTED_CMS,
    'cnb': EXTRACTED_CNB,
}


# --- New helper: clear and extract only .psv files into extracted folder ---
def _extract_psvs_to_extracted(tar_path: Path, module: str) -> List[Path]:
    """Extract inner 'out' tar (if present) and copy all .psv files into Extracted_psv_files/<module>.

    Returns list of extracted PSV paths (absolute).
    """
    out_dir = _module_to_extracted.get(module)
    if out_dir is None:
        raise ValueError(f'Unknown module {module}')
    # clear target folder
    if out_dir.exists():
        for p in out_dir.iterdir():
            try:
                if p.is_file():
                    p.unlink()
                else:
                    shutil.rmtree(p)
            except Exception:
                pass
    out_dir.mkdir(parents=True, exist_ok=True)

    if tar_path is None:
        return []

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        # extract outer tar
        try:
            with tarfile.open(tar_path) as t:
                t.extractall(path=tmp)
        except Exception as e:
            # allow gz or tar depending on archive
            raise
        # find inner out tar if helper available, else attempt common names
        inner_tar = None
        if _find_inner_out_tar is not None:
            inner_tar = _find_inner_out_tar(tmp, module + '_out')
            if inner_tar is None:
                # try other common keywords
                for kw in ['esn_out', 'cms_out', 'lgd_commercial', 'ccms_out', 'cnb_out']:
                    inner_tar = _find_inner_out_tar(tmp, kw)
                    if inner_tar:
                        break
        # if inner tar found, extract it into tmp_extract, else search for .psv in tmp tree
        extract_root = tmp
        if inner_tar is not None:
            extract_root = tmp / 'inner'
            extract_root.mkdir(exist_ok=True)
            try:
                with tarfile.open(inner_tar) as it:
                    it.extractall(path=extract_root)
            except Exception:
                # fallback: use parent tmp tree
                extract_root = tmp
        # Now copy all .psv files found under extract_root into out_dir
        found = []
        for p in extract_root.rglob('*.psv'):
            try:
                dest = out_dir / p.name
                shutil.copy2(p, dest)
                found.append(dest)
            except Exception:
                continue
        return found


# --- New helper: strip timestamp from SQL table token ---
def _strip_timestamp_from_token(tok: Optional[str]) -> Optional[str]:
    """Remove trailing timestamp-like suffix or placeholder from token to provide base name.
    E.g. Facility_cnb_out_20250403_202505232005 -> Facility_cnb_out
    E.g. Facility_ccms_out_{*} -> Facility_ccms_out
    If no timestamp pattern found returns original token. Accepts/returns Optional to reflect callers.
    """
    if tok is None:
        return None
    # if placeholder marker present, strip it
    if '{*}' in tok:
        return tok.replace('_{*}', '')
    # remove trailing _<digits>[_digits...]
    m = re.match(r'^(.*?)(_\d{6,}.*)$', tok)
    if m:
        return m.group(1)
    return tok


# --- New helper: find psv file by token in extracted folder ---
def _find_psv_for_token(token: str, module: str) -> Optional[Path]:
    out_dir = _module_to_extracted.get(module)
    if out_dir is None or not out_dir.exists():
        return None
    stem = token
    # try exact match
    candidate = out_dir / (stem + '.psv')
    if candidate.exists():
        return candidate
    # try with stripped ts
    base = _strip_timestamp_from_token(token)
    # prefer files that start with token, then start with base, then contain base
    candidates = list(out_dir.glob('*.psv'))
    starts_token = [p for p in candidates if p.stem.startswith(stem)]
    if starts_token:
        # choose longest stem match
        starts_token.sort(key=lambda p: len(p.stem), reverse=True)
        return starts_token[0]
    starts_base = [p for p in candidates if p.stem.startswith(base)]
    if starts_base:
        starts_base.sort(key=lambda p: len(p.stem), reverse=True)
        return starts_base[0]
    contains_base = [p for p in candidates if base in p.stem]
    if contains_base:
        contains_base.sort(key=lambda p: len(p.stem), reverse=True)
        return contains_base[0]
    return None


# --- New helper: minimal SQL parser for SELECT ... FROM ... LEFT JOIN ... ON ... ---
def _parse_simple_sql(sql_text: str) -> Dict:
    """Parse a limited SQL (SELECT ... FROM ... LEFT JOIN ... ON ...) into dict with:
    - selects: list of {'table':token,'column':col,'alias':optional}
    - from_table: token
    - joins: list of {'right_table':token,'on': [(left_qual,right_qual), ...], 'type': 'LEFT'}
    This parser is intentionally limited to the SQL shapes used by prompts.
    """
    txt = sql_text.strip().rstrip(';')
    # collapse whitespace
    txt = re.sub(r'\s+', ' ', txt)
    pat = re.match(r'(?i)SELECT (.*?) FROM (.*)', txt, flags=re.IGNORECASE)
    if not pat:
        return {'selects': [], 'from': None, 'joins': []}
    select_part = pat.group(1).strip()
    rest = pat.group(2).strip()
    # split select columns by comma outside parentheses
    cols = [c.strip() for c in re.split(r',\s*(?![^()]*\))', select_part) if c.strip()]
    selects = []
    for c in cols:
        # handle alias with AS
        m = re.match(r'(.+?)\s+AS\s+(.+)', c, flags=re.IGNORECASE)
        if m:
            left = m.group(1).strip()
            alias = m.group(2).strip()
        else:
            left = c
            alias = None
        # handle qualified token.table.column or table.column
        parts = left.split('.')
        if len(parts) >= 2:
            table = parts[0].strip()
            column = parts[-1].strip()
        else:
            table = None
            column = left.strip()
        selects.append({'table': table, 'column': column, 'alias': alias})
    # parse FROM and JOIN clauses: we will split by LEFT JOIN
    joins = []
    # find first FROM token (before any LEFT JOIN)
    from_token = None
    # split rest by ' LEFT JOIN ' (case-insensitive)
    parts = re.split(r'(?i)\sLEFT\s+JOIN\s', rest)
    # first part contains FROM <table> [maybe alias]
    first = parts[0].strip()
    # remove leading possible 'FROM '
    if first.upper().startswith('FROM '):
        first = first[5:].strip()
    # first token may include trailing WHERE etc, but we ignore WHERE in this limited parser
    # get first token as the from table
    m2 = re.match(r'([\w_{}*]+)', first)
    from_token = m2.group(1) if m2 else None
    # now for each subsequent part, parse the right table and ON clause
    for p in parts[1:]:
        # p is like '<right_table> ON <conditions> ...'
        m3 = re.match(r'([\w_{}*]+)\s+ON\s+(.*)', p, flags=re.IGNORECASE)
        if not m3:
            continue
        right_table = m3.group(1).strip()
        on_clause = m3.group(2).strip()
        # on_clause may contain AND and possible JOIN continuation; keep until next JOIN or end
        # remove trailing ' LEFT JOIN ...' if any (we split, so not present)
        # split conditions by AND
        conds = [cc.strip() for cc in re.split(r'(?i)\s+AND\s+', on_clause) if cc.strip()]
        on_pairs = []
        for cond in conds:
            # cond like A.col = B.col
            mm = re.match(r'([\w_.{}*]+)\s*=\s*([\w_.{}*]+)', cond)
            if mm:
                leftq = mm.group(1).strip()
                rightq = mm.group(2).strip()
                on_pairs.append((leftq, rightq))
        joins.append({'right_table': right_table, 'on': on_pairs, 'type': 'LEFT'})
    return {'selects': selects, 'from': from_token, 'joins': joins}


# --- New helper: load PSVs referenced by parsed SQL into dataframes ---
def _load_psvs_for_sql(parsed: Dict, module: str) -> Tuple[Dict[str, pd.DataFrame], List[str], List[str]]:
    """Load required PSV files based on parsed SQL. Returns (df_map, missing_files, missing_columns).

    df_map keys are base table tokens (stripped timestamps) mapped to DataFrame.
    """
    df_map = {}
    missing_files = []
    missing_columns = []
    tables = []
    if parsed.get('from'):
        tables.append(parsed['from'])
    for j in parsed.get('joins', []):
        tables.append(j.get('right_table'))
    # uniq and preserve order
    seen = set()
    tables = [t for t in tables if t and not (t in seen or seen.add(t))]
    for t in tables:
        p = _find_psv_for_token(t, module)
        if p is None:
            missing_files.append(t)
            continue
        # load using generic PSV reader; use facility smart for facility files
        try:
            if 'facility' in p.stem.lower():
                df = read_facility_psv_smart(p) if 'read_facility_psv_smart' in globals() else _read_psv_skip_meta(p)
            else:
                df = _read_psv_skip_meta(p) if '_read_psv_skip_meta' in globals() else read_psv_preserve_shape(p)
        except Exception:
            # attempt fallback
            try:
                df = read_psv_preserve_shape(p) if 'read_psv_preserve_shape' in globals() else _read_psv_skip_meta(p)
            except Exception:
                missing_files.append(t)
                continue
        key = _strip_timestamp_from_token(t)
        df_map[key] = df
    # detect missing columns referenced in selects or joins
    # build a set of required unqualified column names
    required_cols = set()
    for sel in parsed.get('selects', []):
        if sel.get('column'):
            required_cols.add(sel.get('column'))
    for j in parsed.get('joins', []):
        for l, r in j.get('on', []):
            # get column after last dot
            lc = l.split('.')[-1]
            rc = r.split('.')[-1]
            required_cols.add(lc)
            required_cols.add(rc)
    # for each loaded df, check that at least the needed columns for that table exist
    for t in list(df_map.keys()):
        df = df_map[t]
        # which required colums are relevant for this table? check if any required col exists in df (case-insensitive)
        cols_low = [c.lower() for c in df.columns]
        # no strict per-table mapping here; we'll detect missing columns globally later
    # global missing columns detection (simple): check that for each required col at least one loaded DF contains it
    for rc in required_cols:
        found_any = False
        for df in df_map.values():
            if any(str(c).strip().lower() == rc.strip().lower() for c in df.columns):
                found_any = True
                break
        if not found_any:
            missing_columns.append(rc)
    return df_map, missing_files, missing_columns


# --- New helper: execute parsed SQL on loaded DF map to return final dataframe ---
def _execute_parsed_sql(parsed: Dict, df_map: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Given parsed SQL dict and df_map keyed by base token (no ts), perform LEFT JOINs and SELECT to produce final DataFrame.
    This implements a conservative, explicit merge strategy using prefixed column names to avoid collisions.
    """
    if parsed.get('from') is None:
        return pd.DataFrame()
    from_tok = _strip_timestamp_from_token(parsed['from'])
    if from_tok not in df_map:
        # try to find best match key
        keys = list(df_map.keys())
        if keys:
            from_tok = keys[0]
        else:
            return pd.DataFrame()
    # Make a working copy where each DF has columns renamed to <table>__<col>
    prefixed = {}
    for k, df in df_map.items():
        mapping = {col: f"{k}__{col}" for col in df.columns}
        prefixed[k] = df.rename(columns=mapping).copy()
    # start with from_df
    result = prefixed[from_tok].copy()
    # perform joins in order
    for j in parsed.get('joins', []):
        right_raw = j.get('right_table')
        right_key = _strip_timestamp_from_token(right_raw)
        if right_key not in prefixed:
            # try to find key containing right_key
            right_key = next((x for x in prefixed.keys() if x.startswith(right_key)), None)
        if right_key is None:
            continue
        right_df = prefixed[right_key]
        # build left_on and right_on lists based on ON pairs; pairs are qualified names
        left_on = []
        right_on = []
        for lq, rq in j.get('on', []):
            lparts = lq.split('.')
            rparts = rq.split('.')
            ltab = _strip_timestamp_from_token(lparts[0]) if len(lparts) > 1 else from_tok
            rtab = _strip_timestamp_from_token(rparts[0]) if len(rparts) > 1 else right_key
            lcol = lparts[-1]
            rcol = rparts[-1]
            left_on.append(f"{ltab}__{lcol}")
            right_on.append(f"{rtab}__{rcol}")
        # filter only pairs that exist in both dataframes
        valid_left = []
        valid_right = []
        for lo, ro in zip(left_on, right_on):
            if lo in result.columns and ro in right_df.columns:
                valid_left.append(lo)
                valid_right.append(ro)
        try:
            if valid_left and len(valid_left) == len(valid_right):
                result = result.merge(right_df, left_on=valid_left, right_on=valid_right, how='left')
            else:
                # fallback: try to merge on any common column names (unprefixed)
                common = []
                left_cols = {c.split('__')[-1].lower(): c for c in result.columns}
                right_cols = {c.split('__')[-1].lower(): c for c in right_df.columns}
                for colname, lfull in left_cols.items():
                    if colname in right_cols:
                        common.append((lfull, right_cols[colname]))
                if common:
                    # build explicit left/right lists from common pairs
                    left_list = [pair[0] for pair in common]
                    right_list = [pair[1] for pair in common]
                    result = result.merge(right_df, left_on=left_list, right_on=right_list, how='left')
                else:
                    # last resort: concatenate columns (cartesian)
                    result = pd.concat([result.reset_index(drop=True), right_df.reset_index(drop=True)], axis=1)
        except Exception:
            # if merge failed, attempt a safe concat
            result = pd.concat([result.reset_index(drop=True), right_df.reset_index(drop=True)], axis=1)
    # Now build final select column list
    final_cols = []
    final_rename = {}
    seen_names = {}
    for sel in parsed.get('selects', []):
        table_tok = sel.get('table')
        col = sel.get('column')
        alias = sel.get('alias')
        if table_tok:
            key = _strip_timestamp_from_token(table_tok)
            candidate = f"{key}__{col}"
            # if candidate not exist, try to find any column that endswith __col
            if candidate not in result.columns:
                matches = [c for c in result.columns if c.lower().endswith('__' + col.lower())]
                candidate = matches[0] if matches else None
        else:
            # unqualified column: try to find unique column in result
            matches = [c for c in result.columns if c.lower().endswith('__' + col.lower()) or c.lower() == col.lower()]
            candidate = matches[0] if matches else None
        if candidate is None:
            # missing column; create an empty column to preserve select order
            fake = f'__MISSING__{col}'
            result[fake] = ''
            final_cols.append(fake)
            final_rename[fake] = alias or col
            continue
        final_cols.append(candidate)
        # determine final display name
        display = alias or col
        # ensure uniqueness
        if display in seen_names:
            display = f"{table_tok}_{display}" if table_tok else f"{display}_{seen_names[display]+1}"
            seen_names[display] = seen_names.get(display, 0) + 1
        else:
            seen_names[display] = 1
        final_rename[candidate] = display
    # select and rename
    df_final = result.loc[:, final_cols].copy()
    df_final = df_final.rename(columns=final_rename)
    return df_final


# --- Edits in view(): wire Verify buttons to extract PSVs and set consolidated-ready flags ---
# We'll insert small changes in the existing view() function below where Upload File and Verify buttons are handled.

def _placeholder_generate():
    # create a very small consolidated report excel in memory
    df = pd.DataFrame({'A': [1, 2, 3], 'B': ['x', 'y', 'z']})
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    out = REPORTS_ROOT / f'consolidated_report_{ts}.xlsx'
    df.to_excel(out, index=False, sheet_name='Consolidated')
    return out


# --- New helper: export a dataframe to formatted Excel ---
def _export_df_to_excel(df: pd.DataFrame, module: str, report_dir: Path) -> Path:
    report_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    out_xlsx = report_dir / f'{module.lower()}_consolidated_report_{ts}.xlsx'
    sheet_name = f"{module.upper()}_Consolidated"
    # write dataframe to module-specific sheet name
    with pd.ExcelWriter(out_xlsx, engine='openpyxl') as writer:
        if df is None or df.empty:
            # create empty sheet
            pd.DataFrame().to_excel(writer, sheet_name=sheet_name, index=False)
        else:
            df.to_excel(writer, sheet_name=sheet_name, index=False)
    # apply formatting: center align and thin border for all used cells
    wb = load_workbook(out_xlsx)
    ws = wb[sheet_name]
    center = Alignment(horizontal='center', vertical='center', wrap_text=False)
    thin = Side(border_style="thin", color="000000")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=ws.max_column):
        for cell in row:
            if cell.value is None:
                cell.value = ''
            cell.alignment = center
            cell.border = border
    wb.save(out_xlsx)
    return out_xlsx


# --- New helper: zip report files ---
def _zip_report_files(paths: List[Path], out_zip: Path) -> Path:
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_zip, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for p in paths:
            z.write(p, arcname=p.name)
    return out_zip


# --- Embedded SQL queries ---
# CCMS SQL Without CRE
ccms_sql_query_without_cre = """
SELECT 
    Facility_ccms_in_{*}.deposit, Facility_ccms_in_{*}.SharedLimitTXID, Facility_ccms_in_{*}.UCCIndicator,
    Facility_ccms_in_{*}.CREType, Facility_ccms_in_{*}.ABLIndicator,Facility_ccms_in_{*}.REPortfolioType,
    Facility_ccms_in_{*}.EnrollList,Collateral_ccms_out_{*}.CollateralID,Collateral_ccms_out_{*}.SegmentID,Collateral_ccms_out_{*}.ActualLTV,Collateral_ccms_out_{*}.SegmentIDUpdateDate,Collateral_ccms_out_{*}.CollateralCountryCode,Collateral_ccms_out_{*}.LGDProductPurposeCode,Collateral_ccms_out_{*}.AllocationValue,Collateral_ccms_out_{*}.UCCIndicator,Collateral_ccms_out_{*}.LevelErrorList,Collateral_ccms_in_{*}.GuaranteeID,Collateral_ccms_in_{*}.PledgedType,
    Collateral_ccms_out_{*}.CollateralTypeCd,Collateral_ccms_in_{*}.CollateralSubTypeCd,Collateral_ccms_in_{*}.CollateralProvinceStateCd,Collateral_ccms_in_{*}.CollateralMarketAmountCAD,Collateral_ccms_in_{*}.CollateralBookAmountCAD,Collateral_ccms_out_{*}.CollateralAppraisedAmountCAD,Collateral_ccms_in_{*}.PriorLiensAmountCAD,Collateral_ccms_in_{*}.ChargeAmountCAD,Collateral_ccms_in_{*}.EligibleCollateralAmountCAD,Collateral_ccms_in_{*}.CollateralAssignmentTypeCd,Collateral_ccms_out_{*}.LGDProductPurposeCode,Collateral_ccms_out_{*}.ProvidedByCustomerId,Collateral_ccms_out_{*}.UCCIndicator,Collateral_ccms_out_{*}.ValuationMethod,
    Collateral_ccms_out_{*}.ValuationDate,Collateral_ccms_out_{*}.UnderWrittenValue,Collateral_ccms_out_{*}.CROCOComplaintIndicator,Collateral_ccms_out_{*}.ErrorList,Guarantee_ccms_in_{*}.GuaranteeID,
    Guarantee_ccms_in_{*}.GuaranteeType,Guarantee_ccms_in_{*}.GuaranteeSubType,Guarantee_ccms_in_{*}.GBRR,Guarantee_ccms_in_{*}.GuaranteeDocumentId,Guarantee_ccms_in_{*}.GuaranteeIndicators,Guarantee_ccms_in_{*}.GuaranteeAssignmentType,Guarantee_ccms_in_{*}.GuaranteeCAD,Guarantee_ccms_in_{*}.GuarantorType,
    Guarantee_ccms_in_{*}.GuarantorSICCode,Guarantee_ccms_in_{*}.GuarantorSectorTypeCode,Guarantee_ccms_in_{*}.GuarantorBSC,Guarantee_ccms_in_{*}.GuarantorCountyCode,Guarantee_ccms_in_{*}.GuarantorCTS
FROM 
    Facility_ccms_out_{*}
    LEFT JOIN Facility_ccms_in_{*} 
        ON Facility_ccms_out_{*}.FacilityID = Facility_ccms_in_{*}.FacilityID
       AND Facility_ccms_out_{*}.ccmsBorrowerCTS = Facility_ccms_in_{*}.ccmsBorrowerCTS
    LEFT JOIN Collateral_ccms_out_{*} 
        ON Facility_ccms_out_{*}.FacilityID = Collateral_ccms_out_{*}.FacilityID
    LEFT JOIN Borrower_ccms_in_{*} 
        ON Collateral_ccms_out_{*}.ccmsBorrowerCTS = Borrower_ccms_in_{*}.ccmsBorrowerCTS
    LEFT JOIN Pledge_ccms_in_{*} 
        ON Collateral_ccms_out_{*}.CollateralID = Pledge_ccms_in_{*}.CollateralID
    LEFT JOIN Collateral_ccms_in_{*} 
        ON Pledge_ccms_in_{*}.GuaranteeID = Guarantee_ccms_in_{*}.GuaranteeID
"""

# CCMS SQL With CRE
ccms_sql_query_with_cre = """
SELECT 
    Facility_ccms_in_{*}.deposit, Facility_ccms_in_{*}.SharedLimitTXID, Facility_ccms_in_{*}.UCCIndicator,
    Facility_ccms_in_{*}.CREType, Facility_ccms_in_{*}.ABLIndicator,Facility_ccms_in_{*}.REPortfolioType,
    Facility_ccms_in_{*}.EnrollList,Collateral_ccms_out_{*}.CollateralID,Collateral_ccms_out_{*}.SegmentID,Collateral_ccms_out_{*}.ActualLTV,Collateral_ccms_out_{*}.SegmentIDUpdateDate,Collateral_ccms_out_{*}.CollateralCountryCode,Collateral_ccms_out_{*}.LGDProductPurposeCode,Collateral_ccms_out_{*}.AllocationValue,Collateral_ccms_out_{*}.UCCIndicator,Collateral_ccms_out_{*}.LevelErrorList,Collateral_ccms_in_{*}.GuaranteeID,Collateral_ccms_in_{*}.PledgedType,
    Collateral_ccms_out_{*}.CollateralTypeCd,Collateral_ccms_in_{*}.CollateralSubTypeCd,Collateral_ccms_in_{*}.CollateralProvinceStateCd,Collateral_ccms_in_{*}.CollateralMarketAmountCAD,Collateral_ccms_in_{*}.CollateralBookAmountCAD,Collateral_ccms_out_{*}.CollateralAppraisedAmountCAD,Collateral_ccms_in_{*}.PriorLiensAmountCAD,Collateral_ccms_in_{*}.ChargeAmountCAD,Collateral_ccms_in_{*}.EligibleCollateralAmountCAD,Collateral_ccms_in_{*}.CollateralAssignmentTypeCd,Collateral_ccms_out_{*}.LGDProductPurposeCode,Collateral_ccms_out_{*}.ProvidedByCustomerId,Collateral_ccms_out_{*}.UCCIndicator,Collateral_ccms_out_{*}.ValuationMethod,
    Collateral_ccms_out_{*}.ValuationDate,Collateral_ccms_out_{*}.UnderWrittenValue,Collateral_ccms_out_{*}.CROCOComplaintIndicator,Collateral_ccms_out_{*}.ErrorList,Guarantee_ccms_in_{*}.GuaranteeID,
    Guarantee_ccms_in_{*}.GuaranteeType,Guarantee_ccms_in_{*}.GuaranteeSubType,Guarantee_ccms_in_{*}.GBRR,Guarantee_ccms_in_{*}.GuaranteeDocumentId,Guarantee_ccms_in_{*}.GuaranteeIndicators,Guarantee_ccms_in_{*}.GuaranteeAssignmentType,Guarantee_ccms_in_{*}.GuaranteeCAD,Guarantee_ccms_in_{*}.GuarantorType,
    Guarantee_ccms_in_{*}.GuarantorSICCode,Guarantee_ccms_in_{*}.GuarantorSectorTypeCode,Guarantee_ccms_in_{*}.GuarantorBSC,Guarantee_ccms_in_{*}.GuarantorCountyCode,Guarantee_ccms_in_{*}.GuarantorCTS
FROM 
    Facility_ccms_out_{*}
    LEFT JOIN Facility_ccms_in_{*} 
        ON Facility_ccms_out_{*}.FacilityID = Facility_ccms_in_{*}.FacilityID
       AND Facility_ccms_out_{*}.ccmsBorrowerCTS = Facility_ccms_in_{*}.ccmsBorrowerCTS
    LEFT JOIN Collateral_ccms_out_{*} 
        ON Facility_ccms_out_{*}.FacilityID = Collateral_ccms_out_{*}.FacilityID
    LEFT JOIN Borrower_ccms_in_{*} 
        ON Collateral_ccms_out_{*}.ccmsBorrowerCTS = Borrower_ccms_in_{*}.ccmsBorrowerCTS
    LEFT JOIN Pledge_ccms_in_{*} 
        ON Collateral_ccms_out_{*}.CollateralID = Pledge_ccms_in_{*}.CollateralID
    LEFT JOIN Collateral_ccms_in_{*} 
        ON Pledge_ccms_in_{*}.GuaranteeID = Guarantee_ccms_in_{*}.GuaranteeID
"""

# CMS SQL
cms_sql_query = """
SELECT 
    Facility_cms_in_{*}.deposit, Facility_cms_in_{*}.SharedLimitTXID, Facility_cms_in_{*}.UCCIndicator,
    Facility_cms_in_{*}.CREType, Facility_cms_in_{*}.ABLIndicator,Facility_cms_in_{*}.REPortfolioType,
    Facility_cms_in_{*}.EnrollList,Collateral_cms_out_{*}.CollateralID,Collateral_cms_out_{*}.SegmentID,Collateral_cms_out_{*}.ActualLTV,Collateral_cms_out_{*}.SegmentIDUpdateDate,Collateral_cms_out_{*}.CollateralCountryCode,Collateral_cms_out_{*}.LGDProductPurposeCode,Collateral_cms_out_{*}.AllocationValue,Collateral_cms_out_{*}.UCCIndicator,Collateral_cms_out_{*}.LevelErrorList,Collateral_cms_in_{*}.GuaranteeID,Collateral_cms_in_{*}.PledgedType,
    Collateral_cms_out_{*}.CollateralTypeCd,Collateral_cms_in_{*}.CollateralSubTypeCd,Collateral_cms_in_{*}.CollateralProvinceStateCd,Collateral_cms_in_{*}.CollateralMarketAmountCAD,Collateral_cms_in_{*}.CollateralBookAmountCAD,Collateral_cms_out_{*}.CollateralAppraisedAmountCAD,Collateral_cms_in_{*}.PriorLiensAmountCAD,Collateral_cms_in_{*}.ChargeAmountCAD,Collateral_cms_in_{*}.EligibleCollateralAmountCAD,Collateral_cms_in_{*}.CollateralAssignmentTypeCd,Collateral_cms_out_{*}.LGDProductPurposeCode,Collateral_cms_out_{*}.ProvidedByCustomerId,Collateral_cms_out_{*}.UCCIndicator,Collateral_cms_out_{*}.ValuationMethod,
    Collateral_cms_out_{*}.ValuationDate,Collateral_cms_out_{*}.UnderWrittenValue,Collateral_cms_out_{*}.CROCOComplaintIndicator,Collateral_cms_out_{*}.ErrorList,Guarantee_cms_in_{*}.GuaranteeID,
    Guarantee_cms_in_{*}.GuaranteeType,Guarantee_cms_in_{*}.GuaranteeSubType,Guarantee_cms_in_{*}.GBRR,Guarantee_cms_in_{*}.GuaranteeDocumentId,Guarantee_cms_in_{*}.GuaranteeIndicators,Guarantee_cms_in_{*}.GuaranteeAssignmentType,Guarantee_cms_in_{*}.GuaranteeCAD,Guarantee_cms_in_{*}.GuarantorType,
    Guarantee_cms_in_{*}.GuarantorSICCode,Guarantee_cms_in_{*}.GuarantorSectorTypeCode,Guarantee_cms_in_{*}.GuarantorBSC,Guarantee_cms_in_{*}.GuarantorCountyCode,Guarantee_cms_in_{*}.GuarantorCTS
FROM 
    Facility_cms_out_{*}
    LEFT JOIN Facility_cms_in_{*} 
        ON Facility_cms_out_{*}.FacilityID = Facility_cms_in_{*}.FacilityID
       AND Facility_cms_out_{*}.cmsBorrowerCTS = Facility_cms_in_{*}.BorrowerCTS
    LEFT JOIN Collateral_cms_out_{*} 
        ON Facility_cms_out_{*}.FacilityID = Collateral_cms_out_{*}.FacilityID
    LEFT JOIN Borrower_cms_in_{*} 
        ON Collateral_cms_out_{*}.cmsBorrowerCTS = Borrower_cms_in_{*}.cmsBorrowerCTS
    LEFT JOIN Pledge_cms_in_{*} 
        ON Collateral_cms_out_{*}.CollateralID = Pledge_cms_in_{*}.CollateralID
    LEFT JOIN Collateral_cms_in_{*} 
        ON Pledge_cms_in_{*}.GuaranteeID = Guarantee_cms_in_{*}.GuaranteeID
"""

# CNB SQL
cnb_sql_query = """
SELECT 
    Facility_cnb_in_{*}.deposit, Facility_cnb_in_{*}.SharedLimitTXID, Facility_cnb_in_{*}.UCCIndicator,
    Facility_cnb_in_{*}.CREType, Facility_cnb_in_{*}.ABLIndicator,Facility_cnb_in_{*}.REPortfolioType,
    Facility_cnb_in_{*}.EnrollList,Collateral_cnb_out_{*}.CollateralID,Collateral_cnb_out_{*}.SegmentID,Collateral_cnb_out_{*}.ActualLTV,Collateral_cnb_out_{*}.SegmentIDUpdateDate,Collateral_cnb_out_{*}.CollateralCountryCode,Collateral_cnb_out_{*}.LGDProductPurposeCode,Collateral_cnb_out_{*}.AllocationValue,Collateral_cnb_out_{*}.UCCIndicator,Collateral_cnb_out_{*}.LevelErrorList,Collateral_cnb_in_{*}.GuaranteeID,Collateral_cnb_in_{*}.PledgedType,
    Collateral_cnb_out_{*}.CollateralTypeCd,Collateral_cnb_in_{*}.CollateralSubTypeCd,Collateral_cnb_in_{*}.CollateralProvinceStateCd,Collateral_cnb_in_{*}.CollateralMarketAmountCAD,Collateral_cnb_in_{*}.CollateralBookAmountCAD,Collateral_cnb_out_{*}.CollateralAppraisedAmountCAD,Collateral_cnb_in_{*}.PriorLiensAmountCAD,Collateral_cnb_in_{*}.ChargeAmountCAD,Collateral_cnb_in_{*}.EligibleCollateralAmountCAD,Collateral_cnb_in_{*}.CollateralAssignmentTypeCd,Collateral_cnb_out_{*}.LGDProductPurposeCode,Collateral_cnb_out_{*}.ProvidedByCustomerId,Collateral_cnb_out_{*}.UCCIndicator,Collateral_cnb_out_{*}.ValuationMethod,
    Collateral_cnb_out_{*}.ValuationDate,Collateral_cnb_out_{*}.UnderWrittenValue,Collateral_cnb_out_{*}.CROCOComplaintIndicator,Collateral_cnb_out_{*}.ErrorList,Guarantee_cnb_in_{*}.GuaranteeID,
    Guarantee_cnb_in_{*}.GuaranteeType,Guarantee_cnb_in_{*}.GuaranteeSubType,Guarantee_cnb_in_{*}.GBRR,Guarantee_cnb_in_{*}.GuaranteeDocumentId,Guarantee_cnb_in_{*}.GuaranteeIndicators,Guarantee_cnb_in_{*}.GuaranteeAssignmentType,Guarantee_cnb_in_{*}.GuaranteeCAD,Guarantee_cnb_in_{*}.GuarantorType,
    Guarantee_cnb_in_{*}.GuarantorSICCode,Guarantee_cnb_in_{*}.GuarantorSectorTypeCode,Guarantee_cnb_in_{*}.GuarantorBSC,Guarantee_cnb_in_{*}.GuarantorCountyCode,Guarantee_cnb_in_{*}.GuarantorCTS
FROM 
    Facility_cnb_out_{*}
    LEFT JOIN Facility_cnb_in_{*} 
        ON Facility_cnb_out_{*}.FacilityID = Facility_cnb_in_{*}.FacilityID
       AND Facility_cnb_out_{*}.CNBBorrowerCTS = Facility_cnb_in_{*}.CNBBorrowerCTS
    LEFT JOIN Collateral_cnb_out_{*} 
        ON Facility_cnb_out_{*}.FacilityID = Collateral_cnb_out_{*}.FacilityID
    LEFT JOIN Borrower_cnb_in_{*} 
        ON Collateral_cnb_out_{*}.CNBBorrowerCTS = Borrower_cnb_in_{*}.CNBBorrowerCTS
    LEFT JOIN Pledge_cnb_in_{*} 
        ON Collateral_cnb_out_{*}.CollateralID = Pledge_cnb_in_{*}.CollateralID
    LEFT JOIN Collateral_cnb_in_{*} 
        ON Pledge_cnb_in_{*}.GuaranteeID = Guarantee_cnb_in_{*}.GuaranteeID
"""

# --- New function: programmatic generator using embedded SQLs ---
def generate_consolidated_from_constants(ccms_choice: str = 'Without CRE'):
    """Extract PSV files from Uploaded_files, ensure required PSVs/columns exist,
    execute embedded SQLs and export consolidated xlsx files for ccms/cms/cnb.
    Returns list of generated xlsx Paths.
    """
    generated = []
    # choose CCMS SQL based on choice
    ccms_sql = ccms_sql_query_with_cre if (ccms_choice and ccms_choice.strip().lower() == 'with cre') else ccms_sql_query_without_cre
    modules = [
        ('ccms', UPLOADED_CC, ccms_sql, REPORTS_CC, EXTRACTED_CC),
        ('cms', UPLOADED_CMS, cms_sql_query, REPORTS_CMS, EXTRACTED_CMS),
        ('cnb', UPLOADED_CNB, cnb_sql_query, REPORTS_CNB, EXTRACTED_CNB),
    ]

    for module, upload_dir, sql_text, report_dir, extract_dir in modules:
        # find a tar in upload_dir (pick newest)
        tar_files = list(upload_dir.glob('*')) if upload_dir.exists() else []
        tar_files = [p for p in tar_files if p.is_file() and (p.suffix == '.tar' or p.name.endswith('.tar.gz') or p.suffix == '.gz')]
        if not tar_files:
            print(f'[WARN] No uploaded tar found for {module} in {upload_dir}; skipping')
            continue
        tar_files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        tar_path = tar_files[0]
        print(f'[INFO] Using {tar_path} for module {module}')
        # extract PSVs into extracted folder
        extracted = _extract_psvs_to_extracted(tar_path, module)
        print(f'[INFO] Extracted {len(extracted)} PSV files into {extract_dir}')
        # parse SQL
        parsed = _parse_simple_sql(sql_text)
        df_map, missing_files, missing_cols = _load_psvs_for_sql(parsed, module)
        # If missing, create dummy PSV files
        if missing_files or missing_cols:
            print(f'[ERROR] Missing inputs for {module}: files={missing_files} cols={missing_cols}; skipping generation for this module.')
            continue
        # execute parsed SQL
        try:
            df_final = _execute_parsed_sql(parsed, df_map)
        except Exception as e:
            print(f'[ERROR] Failed to execute SQL for {module}: {e}')
            continue
        # export
        try:
            out = _export_df_to_excel(df_final, module, report_dir)
            generated.append(out)
            print(f'[INFO] Generated consolidated report for {module}: {out}')
        except Exception as e:
            print(f'[ERROR] Failed to write report for {module}: {e}')

    return generated


def _reset_consolidated_state():
    """Reset Streamlit session state items related to consolidated generation so the user can start fresh."""
    # Do NOT set file_uploader-backed keys here (e.g. 'ccms_upload') —
    # Streamlit raises an error if you set them via session_state.
    keys_defaults = {
        'consol_ccms_ready': False,
        'consol_cms_ready': False,
        'consol_cnb_ready': False,
        'ccms_report_generation': False,
        'cms_report_generation': False,
        'cnb_report_generation': False,
        'ccms_verified': '',
        'cms_verified': '',
        'cnb_verified': '',
        'ccms_select': '',
        'cms_select': '',
        'cnb_select': '',
        'ccms_sql': ccms_sql_query_with_cre if st.session_state.get('ccms_query_type','Without CRE').strip().lower() == 'with cre' else ccms_sql_query_without_cre,
        'cms_sql': cms_sql_query,
        'cnb_sql': cnb_sql_query,
        'ccms_query_type_prev': None,
        'ccms_query_type': 'Without CRE',
    }
    for k, v in keys_defaults.items():
        st.session_state[k] = v
    # reset matched maps
    st.session_state.pop('ccms_matched_map', None)
    st.session_state.pop('cms_matched_map', None)
    st.session_state.pop('cnb_matched_map', None)


def view():
    # Ensure required folders(uploads, reports) exist on Root
    list_of_dirs = [UPLOADED_CC, UPLOADED_CMS, UPLOADED_CNB, EXTRACTED,EXTRACTED_CC, EXTRACTED_CMS, EXTRACTED_CNB, REPORTS_CC, REPORTS_CMS, REPORTS_CNB]
    _ensure_dirs(list_of_dirs)

    st.markdown("# LGD UAT Automation Solution", text_alignment="center")
    st.title('Consolidated Report Generator', text_alignment="center")
    st.caption('Upload or Select CCMS/CMS/CNB TAR files to generate Consolidated reports', text_alignment="center")

    # Mark that we are on the consolidated page so other parts of app can detect it
    st.session_state['home_consolidated'] = True

    # Refresh button for consolidated page (top-right of CCMS section)
    if st.button('Refresh', key='refresh_top'):
        _reset_consolidated_state()
        rerun = getattr(st, 'experimental_rerun', None)
        if callable(rerun):
            try:
                rerun()
            except Exception:
                pass

    # Initialize session keys used to remember verified status and file identity
    if 'ccms_report_generation' not in st.session_state:
        st.session_state['ccms_report_generation'] = False
    if 'cms_report_generation' not in st.session_state:
        st.session_state['cms_report_generation'] = False
    if 'cnb_report_generation' not in st.session_state:
        st.session_state['cnb_report_generation'] = False

    if 'ccms_verified' not in st.session_state:
        st.session_state['ccms_verified'] = ''
    if 'cms_verified' not in st.session_state:
        st.session_state['cms_verified'] = ''
    if 'cnb_verified' not in st.session_state:
        st.session_state['cnb_verified'] = ''

    # consolidated ready flags
    if 'consol_ccms_ready' not in st.session_state:
        st.session_state['consol_ccms_ready'] = False
    if 'consol_cms_ready' not in st.session_state:
        st.session_state['consol_cms_ready'] = False
    if 'consol_cnb_ready' not in st.session_state:
        st.session_state['consol_cnb_ready'] = False

    # SQL input defaults
    if 'ccms_sql' not in st.session_state:
        st.session_state['ccms_sql'] = ''
    if 'cms_sql' not in st.session_state:
        st.session_state['cms_sql'] = ''
    if 'cnb_sql' not in st.session_state:
        st.session_state['cnb_sql'] = ''

    # CCMS section
    st.subheader('CCMS Section:---')

    ccms_select = st.selectbox('Select CCMS TAR File', options=[''] + _recent_files(UPLOADED_CC), key='ccms_select')
    ccms_upload = st.file_uploader('Or Upload CCMS TAR File', type=['tar', 'gz'],key='ccms_upload')
    ccms_path = None
    if ccms_upload is not None:
        if not _validate_ccms_filename(ccms_upload.name):
            st.error("Please upload 'lgd_ccms_in_out_{timestamp}.tar.gz' or 'ccms_out_{timestamp}.tar.gz'")
        else:
            ccms_path = _save_uploaded(ccms_upload, UPLOADED_CC)
            st.success(f'Uploaded to {ccms_path}')
    elif ccms_select:
        ccms_path = UPLOADED_CC / ccms_select


    # Keep verification only while selected/uploaded files for CCMS remain unchanged
    current_ccms = str(ccms_path) if ccms_path is not None else ''

    # New: select box for predefined query type (With CRE / Without CRE)
    ccms_query_type = st.selectbox('Predefined query type (CCMS)', options=['Without CRE', 'With CRE'], index=0)
    # maintain previous choice to detect change
    prev_choice = st.session_state.get('ccms_query_type_prev')
    st.session_state['ccms_query_type'] = ccms_query_type
    # Choose default SQL based on selection
    chosen_ccms_sql = ccms_sql_query_with_cre if ccms_query_type.strip().lower() == 'with cre' else ccms_sql_query_without_cre
    # If SQL area not set yet or user changed the CRE selection, initialize/update it
    if st.session_state.get('ccms_sql','') == '' or prev_choice != ccms_query_type:
        st.session_state['ccms_sql'] = chosen_ccms_sql
    # store prev
    st.session_state['ccms_query_type_prev'] = ccms_query_type

    # Show an editable SQL text area for CCMS (user can edit before generating)
    st.markdown('**CCMS SQL (Read-Only)**')
    # Display CCMS SQL as Read-Only (user cannot edit in the UI)
    st.text_area('CCMS SQL (Read-Only)', value=st.session_state.get('ccms_sql',''), key='ccms_sql', height=220, disabled=True)

    # If files changed since last verification, clear the verified flag
    if st.session_state.get('ccms_verified', '') != current_ccms:
        # Only clear the generation flag if the stored verification does not match current selection
        st.session_state['ccms_report_generation'] = False

    if st.session_state.get('ccms_report_generation') and st.session_state.get('ccms_verified') == current_ccms:
        st.success('CCMS files verified')
    else:
        if ccms_path :
            col1, col2, col3, col4, col5, col6, col7, col8, col9 = st.columns(9)
            with col5:
                if st.button('Upload File and Verify (CCMS)', key='verify_ccms'):
                    with st.spinner(f'Extracting PSV files from {ccms_path}'):  # type: ignore
                        _extract_psvs_to_extracted(ccms_path, 'ccms')
                    # parse CCMS SQL and compute matched PSV filenames to show the user
                    try:
                        parsed = _parse_simple_sql(st.session_state.get('ccms_sql',''))
                        matched_map = _matched_psv_paths(parsed, 'ccms')
                        # persist a token->filename map (filename or None) so we can render left-aligned below
                        map_dict = {t: (p.name if p is not None else None) for t, p in matched_map.items()}
                        st.session_state['ccms_matched_map'] = map_dict
                        # compute quick lists for warnings (kept for backward compatibility)
                        matched_list = [fn for fn in map_dict.values() if fn]
                        missing_tokens = [t for t, fn in map_dict.items() if fn is None]
                        # don't render here (centered); render left-aligned after this verify block
                    except Exception:
                        # ignore parsing/display failure, continue with existing behavior
                        pass
                    st.session_state['ccms_report_generation'] = True
                    st.session_state['ccms_verified'] = current_ccms
                    # mark consolidated ready for CCMS
                    st.session_state['consol_ccms_ready'] = True
                    st.success('CCMS files verified')
        else:
            col1, col2, col3, col4, col5, col6, col7, col8, col9 = st.columns(9)
            with col5:
                st.button('Upload File and Verify (CCMS)', disabled=True, key='verify_ccms_disabled')

    # Left-aligned display of the matched PSV files (token -> filename)
    # Rendered here (outside the centered columns) so it appears at the left margin.
    if st.session_state.get('ccms_matched_map'):
        try:
            token_rows_display = [{'token': t, 'matched_filename': (fn or 'NOT FOUND')} for t, fn in st.session_state.get('ccms_matched_map', {}).items()]
            with st.expander('Matched PSV files (token -> filename)', expanded=False):
                # Render as a simple markdown bullet list so items align at the left margin
                for row in token_rows_display:
                    fn = row.get('matched_filename') or 'NOT FOUND'
                    st.markdown(f'- {fn}')
        except Exception:
            for t, fn in st.session_state.get('ccms_matched_map', {}).items():
                st.markdown(f'- {fn or "NOT FOUND"}')

    st.markdown('---')


    ###############################################

    # CMS section
    st.subheader('CMS Section:---')

    cms_select = st.selectbox('Select CMS TAR File', options=[''] + _recent_files(UPLOADED_CMS), key='cms_select')
    cms_upload = st.file_uploader('Or Upload CMS TAR File', type=['tar', 'gz'], key='cms_upload')
    cms_path = None
    if cms_upload is not None:
        if not _validate_cms_filename(cms_upload.name):
            st.error("Please upload 'lgd_commercial_in_out_{timestamp}.tar.gz' or 'esn_out_{timestamp}.tar.gz' or 'cms_out_{timestamp}.tar.gz'")
        else:
            cms_path = _save_uploaded(cms_upload, UPLOADED_CMS)
            st.success(f'Uploaded to {cms_path}')
    elif cms_select:
        cms_path = UPLOADED_CMS / cms_select

    # Keep verification only while selected/uploaded files for CMS remain unchanged
    current_cms = str(cms_path) if cms_path is not None else ''

    # After CMS verify UI, ensure CMS SQL area exists and is prefilled
    # Initialize CMS SQL if empty
    if st.session_state.get('cms_sql','') == '':
        st.session_state['cms_sql'] = cms_sql_query
    st.markdown('**CMS SQL (Read-Only)**')
    # Display CMS SQL as Read-Only (user cannot edit in the UI)
    st.text_area('CMS SQL (Read-Only)', value=st.session_state.get('cms_sql',''), key='cms_sql', height=220, disabled=True)

    # If files changed since last verification, clear the verified flag
    if st.session_state.get('cms_verified', '') != current_cms:
        # Only clear the generation flag if the stored verification does not match current selection
        st.session_state['cms_report_generation'] = False

    if st.session_state.get('cms_report_generation') and st.session_state.get('cms_verified') == current_cms:
        st.success('CMS files verified')
    else:
        if cms_path:
            col1, col2, col3, col4, col5, col6, col7, col8, col9 = st.columns(9)
            with col5:
                if st.button('Upload File and Verify (CMS)', key='verify_cms'):
                    with st.spinner(f'Extracting PSV files from {cms_path}'):  # type: ignore
                        _extract_psvs_to_extracted(cms_path, 'cms')
                    # parse CMS SQL and persist matched PSV filenames to session state
                    try:
                        parsed = _parse_simple_sql(st.session_state.get('cms_sql',''))
                        matched_map = _matched_psv_paths(parsed, 'cms')
                        map_dict = {t: (p.name if p is not None else None) for t, p in matched_map.items()}
                        st.session_state['cms_matched_map'] = map_dict
                        matched_list = [fn for fn in map_dict.values() if fn]
                        missing_tokens = [t for t, fn in map_dict.items() if fn is None]
                        # UI rendering moved below (left-aligned)
                    except Exception:
                        pass
                    st.session_state['cms_report_generation'] = True
                    st.session_state['cms_verified'] = current_cms
                    # mark consolidated ready for CMS
                    st.session_state['consol_cms_ready'] = True
                    st.success('CMS files verified')
        else:
            col1, col2, col3, col4, col5, col6, col7, col8, col9 = st.columns(9)
            with col5:
                st.button('Upload File and Verify (CMS)', disabled=True, key='verify_cms_disabled')

    # Left-aligned display of the matched PSV files for CMS
    if st.session_state.get('cms_matched_map'):
        try:
            token_rows_display = [{'token': t, 'matched_filename': (fn or 'NOT FOUND')} for t, fn in st.session_state.get('cms_matched_map', {}).items()]
            with st.expander('Matched PSV files (token -> filename)', expanded=False):
                for row in token_rows_display:
                    fn = row.get('matched_filename') or 'NOT FOUND'
                    st.markdown(f'- {fn}')
        except Exception:
            for t, fn in st.session_state.get('cms_matched_map', {}).items():
                st.markdown(f'- {fn or "NOT FOUND"}')

    st.markdown('---')

    ###############################################

    # CNB section
    st.subheader('CNB Section:---')

    cnb_select = st.selectbox('Select CNB TAR File', options=[''] + _recent_files(UPLOADED_CNB), key='cnb_select')
    cnb_upload = st.file_uploader('Or Upload CNB TAR File', type=['tar', 'gz'], key='cnb_upload')
    cnb_path = None
    if cnb_upload is not None:
        if not _validate_cnb_filename(cnb_upload.name):
            st.error("Please upload 'cnb_in_out_{timestamp}.tar.gz' or 'cnb_out_{timestamp}.tar.gz'")
        else:
            cnb_path = _save_uploaded(cnb_upload, UPLOADED_CNB)
            st.success(f'Uploaded to {cnb_path}')
    elif cnb_select:
        cnb_path = UPLOADED_CNB / cnb_select

    # Keep verification only while selected/uploaded files for CNB remain unchanged
    current_cnb = str(cnb_path) if cnb_path is not None else ''

    # After CNB verify UI, ensure CNB SQL area exists and is prefilled
    if st.session_state.get('cnb_sql','') == '':
        st.session_state['cnb_sql'] = cnb_sql_query
    st.markdown('**CNB SQL (Read-Only)**')
    # Display CNB SQL as Read-Only (user cannot edit in the UI)
    st.text_area('CNB SQL (Read-Only)', value=st.session_state.get('cnb_sql',''), key='cnb_sql', height=220, disabled=True)

    # If files changed since last verification, clear the verified flag
    if st.session_state.get('cnb_verified', '') != current_cnb:
        # Only clear the generation flag if the stored verification does not match current selection
        st.session_state['cnb_report_generation'] = False

    if st.session_state.get('cnb_report_generation') and st.session_state.get('cnb_verified') == current_cnb:
        st.success('CNB files verified')
    else:
        if cnb_path:
            col1, col2, col3, col4, col5, col6, col7, col8, col9 = st.columns(9)
            with col5:
                if st.button('Upload File and Verify (CNB)', key='verify_cnb'):
                    with st.spinner(f'Extracting PSV files from {cnb_path}'):  # type: ignore
                        _extract_psvs_to_extracted(cnb_path, 'cnb')
                    # parse CNB SQL and persist matched PSV filenames to session state
                    try:
                        parsed = _parse_simple_sql(st.session_state.get('cnb_sql',''))
                        matched_map = _matched_psv_paths(parsed, 'cnb')
                        map_dict = {t: (p.name if p is not None else None) for t, p in matched_map.items()}
                        st.session_state['cnb_matched_map'] = map_dict
                        matched_list = [fn for fn in map_dict.values() if fn]
                        missing_tokens = [t for t, fn in map_dict.items() if fn is None]
                        # UI rendering moved below (left-aligned)
                    except Exception:
                        pass
                    st.session_state['cnb_report_generation'] = True
                    st.session_state['cnb_verified'] = current_cnb
                    # mark consolidated ready for CNB
                    st.session_state['consol_cnb_ready'] = True
                    st.success('CNB files verified')
        else:
            col1, col2, col3, col4, col5, col6, col7, col8, col9 = st.columns(9)
            with col5:
                st.button('Upload File and Verify (CNB)', disabled=True, key='verify_cnb_disabled')

    # Left-aligned display of the matched PSV files for CNB
    if st.session_state.get('cnb_matched_map'):
        try:
            token_rows_display = [{'token': t, 'matched_filename': (fn or 'NOT FOUND')} for t, fn in st.session_state.get('cnb_matched_map', {}).items()]
            with st.expander('Matched PSV files (token -> filename)', expanded=False):
                for row in token_rows_display:
                    fn = row.get('matched_filename') or 'NOT FOUND'
                    st.markdown(f'- {fn}')
        except Exception:
            for t, fn in st.session_state.get('cnb_matched_map', {}).items():
                st.markdown(f'- {fn or "NOT FOUND"}')

    st.markdown('---')

    # Enable generate when any of the modules is flagged ready
    if st.session_state.get('consol_ccms_ready') or st.session_state.get('consol_cms_ready') or st.session_state.get('consol_cnb_ready'):
        # Create stable placeholders for per-module progress UI so widgets get stable IDs and are not recreated
        module_placeholders = {
            'ccms': st.empty(),
            'cms': st.empty(),
            'cnb': st.empty(),
        }
        # placeholders reserved; will populate them when generation starts

        if st.button('Generate Consolidated Report', key='generate_consolidated'):
            reports_generated = []
            errors_found = []
            # Setup overall progress UI similar to regression_generator
            progress_bar = st.progress(0)
            status_box = st.empty()

            # determine which modules to run
            modules_to_run = []
            if st.session_state.get('consol_ccms_ready'):
                modules_to_run.append('ccms')
            if st.session_state.get('consol_cms_ready'):
                modules_to_run.append('cms')
            if st.session_state.get('consol_cnb_ready'):
                modules_to_run.append('cnb')

            # create per-module small progress widgets using the placeholders (stable positions)
            progress_widgets = {}
            for mod in modules_to_run:
                container = module_placeholders[mod]
                container.markdown(f'**{mod.upper()} Report Progress:**')
                pb = container.progress(0)
                stbox = container.empty()
                progress_widgets[mod] = (pb, stbox)

            def make_cb(mod_name):
                def cb(pct, msg):
                    try:
                        # update overall progress bar only
                        try:
                            progress_bar.progress(min(max(int(pct), 0), 100))
                        except Exception:
                            pass
                        # per-module status box only (avoid duplicating messages in overall status_box)
                        pair = progress_widgets.get(mod_name)
                        if pair:
                            pb, stbox = pair
                            try:
                                pb.progress(min(max(int(pct), 0), 100))
                            except Exception:
                                pass
                            try:
                                stbox.info(msg)
                            except Exception:
                                pass
                    except Exception:
                        pass
                return cb

            # run modules sequentially with callbacks to update UI
            # CCMS
            if st.session_state.get('consol_ccms_ready'):
                cb = make_cb('ccms')
                try:
                    cb(0, 'Starting CCMS consolidated generation')
                    sql_text = st.session_state.get('ccms_sql','')
                    if not sql_text.strip():
                        ccms_choice = st.session_state.get('ccms_query_type','Without CRE')
                        sql_text = ccms_sql_query_with_cre if ccms_choice.strip().lower() == 'with cre' else ccms_sql_query_without_cre
                        st.session_state['ccms_sql'] = sql_text
                    cb(20, 'Parsing CCMS SQL')
                    if not sql_text.strip():
                        errors_found.append('CCMS SQL is empty; skipping CCMS')
                    else:
                        parsed = _parse_simple_sql(sql_text)
                        cb(35, 'Loading CCMS PSV files')
                        df_map, missing_files, missing_cols = _load_psvs_for_sql(parsed, 'ccms')
                        if missing_files or missing_cols:
                            cb(60, 'Missing PSV files or columns for CCMS; skipping CCMS generation')
                            errors_found.append(f'CCMS missing inputs: files={missing_files} cols={missing_cols}')
                            raise StopIteration
                        cb(75, 'Executing CCMS SQL joins')
                        df_final = _execute_parsed_sql(parsed, df_map)
                        cb(90, 'Exporting CCMS consolidated Excel')
                        out = _export_df_to_excel(df_final, 'ccms', REPORTS_CC)
                        reports_generated.append(out)
                        cb(100, 'CCMS generation completed')
                except Exception as e:
                    errors_found.append(f'CCMS error: {e}')

            # CMS
            if st.session_state.get('consol_cms_ready'):
                cb = make_cb('cms')
                try:
                    cb(0, 'Starting CMS consolidated generation')
                    sql_text = st.session_state.get('cms_sql','') or cms_sql_query
                    cb(20, 'Parsing CMS SQL')
                    parsed = _parse_simple_sql(sql_text)
                    cb(40, 'Loading CMS PSV files')
                    df_map, missing_files, missing_cols = _load_psvs_for_sql(parsed, 'cms')
                    if missing_files or missing_cols:
                        cb(60, 'Missing PSV files or columns for CMS; skipping CMS generation')
                        errors_found.append(f'CMS missing inputs: files={missing_files} cols={missing_cols}')
                        raise StopIteration
                    cb(80, 'Executing CMS SQL joins')
                    df_final = _execute_parsed_sql(parsed, df_map)
                    cb(90, 'Exporting CMS consolidated Excel')
                    out = _export_df_to_excel(df_final, 'cms', REPORTS_CMS)
                    reports_generated.append(out)
                    cb(100, 'CMS generation completed')
                except Exception as e:
                    errors_found.append(f'CMS error: {e}')

            # CNB
            if st.session_state.get('consol_cnb_ready'):
                cb = make_cb('cnb')
                try:
                    cb(0, 'Starting CNB consolidated generation')
                    sql_text = st.session_state.get('cnb_sql','') or cnb_sql_query
                    cb(20, 'Parsing CNB SQL')
                    parsed = _parse_simple_sql(sql_text)
                    cb(40, 'Loading CNB PSV files')
                    df_map, missing_files, missing_cols = _load_psvs_for_sql(parsed, 'cnb')
                    if missing_files or missing_cols:
                        cb(60, 'Missing PSV files or columns for CNB; skipping CNB generation')
                        errors_found.append(f'CNB missing inputs: files={missing_files} cols={missing_cols}')
                        raise StopIteration
                    cb(80, 'Executing CNB SQL joins')
                    df_final = _execute_parsed_sql(parsed, df_map)
                    cb(90, 'Exporting CNB consolidated Excel')
                    out = _export_df_to_excel(df_final, 'cnb', REPORTS_CNB)
                    reports_generated.append(out)
                    cb(100, 'CNB generation completed')
                except Exception as e:
                    errors_found.append(f'CNB error: {e}')

            if errors_found:
                for e in errors_found:
                    st.warning(e)
            if reports_generated:
                ts = datetime.now().strftime('%Y%m%d_%H%M%S')
                zip_path = REPORTS_ROOT / f'consolidated_report_{ts}.zip'
                _zip_report_files(reports_generated, zip_path)
                with open(zip_path, 'rb') as f:
                    data = f.read()
                col_dl, col_ref = st.columns([3,1])
                with col_dl:
                    st.download_button('Download Consolidated Reports ZIP', data, file_name=zip_path.name, key='download_consolidated_zip')

def _matched_psv_paths(parsed: Dict, module: str) -> Dict[str, Optional[Path]]:
    """Return a mapping from table token (as in SQL) to the matched Path in the extracted folder or None."""
    mapping: Dict[str, Optional[Path]] = {}
    if parsed is None:
        return mapping
    tokens = []
    if parsed.get('from'):
        tokens.append(parsed['from'])
    for j in parsed.get('joins', []):
        rt = j.get('right_table')
        if rt:
            tokens.append(rt)
    # unique preserve order
    seen = set()
    tokens = [t for t in tokens if t and not (t in seen or seen.add(t))]
    for t in tokens:
        p = _find_psv_for_token(t, module)
        mapping[t] = p
    return mapping
