from pathlib import Path
import streamlit as st
import streamlit.components.v1 as components
import pandas as pd
from datetime import datetime
import shutil
from utility import _ensure_dirs, _recent_files, _validate_psv_filename, _validate_filename,  _save_uploaded


# ==========================================================
# Base directory (works even if you run from elsewhere)
# ==========================================================

ROOT = Path(__file__).resolve().parent
DATA_ROOT = ROOT / 'data' / 'psv_modifier'
UPLOADED_FOLDER1 = DATA_ROOT / 'Uploaded_files' / 'Original_File'
UPLOADED_FOLDER2 = DATA_ROOT / 'Uploaded_files' / 'Replace_File'
REPORTS_ROOT = ROOT / 'reports' / 'psv_modifier'
DATA_ROOT.mkdir(parents=True, exist_ok=True)
UPLOADED_FOLDER1.mkdir(parents=True, exist_ok=True)
UPLOADED_FOLDER2.mkdir(parents=True, exist_ok=True)
REPORTS_ROOT.mkdir(parents=True, exist_ok=True)

# --- Module-level helpers (make them importable/testable) ---
def _clear_dir(path: Path):
    if path.exists():
        for p in path.iterdir():
            if p.is_dir():
                shutil.rmtree(p)
            else:
                p.unlink()
    else:
        path.mkdir(parents=True, exist_ok=True)


# New: apply replacements in a normalized (case-insensitive, whitespace-trimmed) way
def apply_replacements(df_psv: pd.DataFrame, df_excel: pd.DataFrame, ref_col_name: str) -> pd.DataFrame:
    """Return a new DataFrame where target columns from df_excel replace values in df_psv.
    Matching on ref_col_name is done case-insensitively with whitespace trimmed.
    df_excel is expected to have the reference column as its first column and one or more target columns.
    """
    if df_psv is None or df_psv.empty:
        return pd.DataFrame()
    if df_excel is None or df_excel.empty:
        return df_psv.copy()

    left = df_psv.copy()
    right = df_excel.copy()

    # Normalize reference values for matching (do not mutate right's column namespace)
    norm_col = '__ref_norm__'
    left[norm_col] = left[ref_col_name].astype(str).str.strip().str.lower()
    right_norm = right.iloc[:, 0].astype(str).str.strip().str.lower()

    # Determine target cols (columns after first in excel)
    target_cols = list(right.columns[1:])
    existing_targets = [c for c in target_cols if c in left.columns]

    # If no targets exist in PSV, return original (drop helper if present)
    if not existing_targets:
        left.drop(columns=[norm_col], inplace=True, errors=True)
        return left

    # Build right_sub explicitly to avoid duplicate column names
    right_sub = pd.DataFrame({norm_col: right_norm})
    for t in existing_targets:
        right_sub[t] = right[t].astype(str)

    right_sub = right_sub.drop_duplicates(subset=[norm_col])

    merged = left.merge(right_sub, on=norm_col, how='left', suffixes=('', '_new'))

    # Apply replacements: for each existing target, use *_new if present and non-empty
    for t in existing_targets:
        new_col = t + '_new'
        if new_col in merged.columns:
            merged[t] = merged.apply(lambda r: r[new_col] if (pd.notna(r[new_col]) and str(r[new_col]).strip() != '') else r[t], axis=1)
            merged.drop(columns=[new_col], inplace=True, errors=True)

    # remove normalization helper
    merged.drop(columns=[norm_col], inplace=True, errors=True)

    return merged


def write_psv_with_preamble(original_path: Path, df: pd.DataFrame, out_path: Path):
    """Write df to out_path as a PSV, preserving any preamble lines from original_path.
    The function locates the first line in original_path that contains the '|' delimiter and treats
    the lines before that as the preamble. If the first '|' line looks like metadata (contains
    'NoOfRecord' or 'BusinessDate'), that line is preserved as preamble and the next '|' line
    is used as the header when available. If the original header line matches the DataFrame columns
    (ignoring whitespace and case), the original header is reused; otherwise a header is constructed
    from df.columns.
    """
    # Read original content if available
    preamble_lines = []
    original_header_line = None
    newline = '\n'
    try:
        text = original_path.read_text(encoding='utf-8', errors='replace')
        lines = text.splitlines()
        newline = '\n'  # writing with LF is fine; keep stable
        start = None
        for i, ln in enumerate(lines):
            if '|' in ln:
                start = i
                break
        if start is not None:
            # If the first '|' line looks like metadata (NoOfRecord or BusinessDate),
            # include it in the preamble and look for the next '|' line as the header.
            first_pipe = lines[start]
            first_pipe_tokens = [t.strip().lower() for t in first_pipe.split('|')]
            if any(tok in ('noofrecord', 'businessdate') for tok in first_pipe_tokens):
                # include the metadata line in the preamble
                preamble_lines = lines[: start + 1]
                # find next '|' line after start to use as header.
                header_line = None
                for j in range(start + 1, len(lines)):
                    if '|' in lines[j]:
                        header_line = lines[j]
                        break
                original_header_line = header_line
            else:
                preamble_lines = lines[:start]
                original_header_line = lines[start]
        else:
            preamble_lines = []
            original_header_line = None
    except Exception:
        preamble_lines = []
        original_header_line = None

    # Decide header line: reuse original if tokens match df columns (ignoring whitespace & case)
    header_line_to_write = '|'.join([str(c) for c in df.columns])
    try:
        if original_header_line is not None:
            orig_tokens = [t.strip().lower() for t in original_header_line.split('|')]
            df_tokens = [str(c).strip().lower() for c in df.columns]
            if orig_tokens == df_tokens:
                header_line_to_write = original_header_line
    except Exception:
        pass

    # Write output file: preamble, header, then rows
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, 'w', encoding='utf-8', newline='') as out:
        for pl in preamble_lines:
            out.write(pl + newline)
        out.write(header_line_to_write + newline)
        # write rows in df column order
        for _, row in df.iterrows():
            # ensure string representation and replace any internal newlines
            vals = [str(row.get(c, '')).replace('\n', ' ').replace('\r', '') for c in df.columns]
            out.write('|'.join(vals) + newline)

def load_psv_for_display(path: Path) -> pd.DataFrame:
    """Load a PSV while handling common preamble patterns:
    - Skips leading lines until the first '|' delimiter.
    - If the first '|' line is a NoOfRecord metadata row or appears numeric, promote the next line as header.
    - Returns a DataFrame with string values and no metadata columns.
    """
    text = path.read_text(encoding='utf-8', errors='replace')
    lines = [ln for ln in text.splitlines()]
    # find first line containing '|'
    start = 0
    for i, ln in enumerate(lines):
        if '|' in ln:
            start = i
            break
    content_lines = lines[start:]
    if not content_lines:
        return pd.DataFrame()

    # If there is at least two lines, inspect first and second to decide header
    header_offset = 0
    if len(content_lines) >= 2:
        first = content_lines[0].split('|')
        second = content_lines[1].split('|')

        def is_numeric_token(t: str) -> bool:
            t = t.strip().replace(',', '')
            if t == '':
                return False
            try:
                float(t)
                return True
            except Exception:
                return False

        first_join = ' '.join(first).lower()
        # If first row is NoOfRecord metadata, use second line as header
        if 'noofrecord' in first_join or 'businessdate' in first_join:
            header_offset = 1
        else:
            # if first line tokens are mostly numeric and second line tokens look like headers (non-numeric), promote second
            if all(is_numeric_token(tok) for tok in first) and any(not is_numeric_token(tok) for tok in second):
                header_offset = 1

    from io import StringIO
    csv_text = '\n'.join(content_lines)
    try:
        df = pd.read_csv(StringIO(csv_text), sep='|', engine='python', header=header_offset, dtype=str, keep_default_na=False)
    except Exception:
        # fallback to safe reader
        df = load_psv_for_display(path)
    # Normalize column names and drop unnamed columns
    df.columns = [str(c).strip() for c in df.columns]
    df = df.loc[:, [c for c in df.columns if c and not str(c).lower().startswith('unnamed')]]
    # Drop any NoOfRecord columns
    df = df.drop(columns=[c for c in df.columns if ('noofrecord' in c.replace('_','').lower()) or ('businessdate' in c.replace('_','').lower())], errors='ignore')
    # Ensure string values
    df = df.fillna('').astype(str)
    return df


# --- Streamlit app code ---
def _reset_psvmodifier_state():
    """Reset Streamlit session state items related to file analyzer so the user can start fresh.
    Note: do NOT set file_uploader-backed keys here (Streamlit errors if you set them). Only reset simple flags and select keys.
    """
    keys_defaults = {
        'file_report_generation': False,
        'folder1_select': '',
        'folder2_select': '',
        'folder1_verified': '',
        'folder2_verified': '',

    }
    for k, v in keys_defaults.items():
        st.session_state[k] = v


def view():
    # Ensure required folders(uploads, reports) exist on Root
    list_of_dirs = [DATA_ROOT, UPLOADED_FOLDER1, UPLOADED_FOLDER2, REPORTS_ROOT]
    _ensure_dirs(list_of_dirs)

    _clear_dir(UPLOADED_FOLDER1)
    _clear_dir(UPLOADED_FOLDER2)

    st.markdown("# LGD UAT Automation Solution", text_alignment="center")
    st.title('PSV File Modifier', text_alignment="center")
    st.caption('Upload or Select PSV Files to generate Modify PSV File', text_alignment="center")

    # Refresh button
    if st.button('Refresh', key='refresh_top'):
        _reset_psvmodifier_state()
        rerun = getattr(st, 'experimental_rerun', None)
        if callable(rerun):
            try:
                rerun()
            except Exception:
                pass

    # Initialize session keys used to remember verified status and file identity
    if 'file_report_generation' not in st.session_state:
        st.session_state['file_report_generation'] = False


    c1, c2 = st.columns(2)
    with c1:
        folder1_sel = st.selectbox('Select PSV File', options=[''] + _recent_files(UPLOADED_FOLDER1), key='folder1_select')
        folder1_upload = st.file_uploader('Or Upload PSV File', type=['psv'], key='folder1_upload')
        folder1_path = None
        if folder1_upload is not None:
            if not _validate_psv_filename(folder1_upload.name):
                st.error("Please upload PSV File")
            else:
                folder1_path = _save_uploaded(folder1_upload, UPLOADED_FOLDER1)
                st.success(f'Uploaded to {folder1_path}')
        elif folder1_sel:
            # when a recent selection is used, set folder1_path so verification/extraction uses it
            folder1_path = UPLOADED_FOLDER1 / folder1_sel
    with c2:
        folder2_sel = st.selectbox('Select Excel File', options=[''] + _recent_files(UPLOADED_FOLDER2), key='folder2_select')
        folder2_upload = st.file_uploader('Or Upload Excel File', type=['xlsx'], key='folder2_upload')
        folder2_path = None
        if folder2_upload is not None:
            if not _validate_filename(folder2_upload.name):
                st.error("Please upload Excel File")
            else:
                folder2_path = _save_uploaded(folder2_upload, UPLOADED_FOLDER2)
                st.success(f'Uploaded to {folder2_path}')
        elif folder2_sel:
            folder2_path = UPLOADED_FOLDER2 / folder2_sel

    # Keep verification only while selected/uploaded files remain unchanged
    current_folder1 = str(folder1_path) if folder1_path is not None else ''
    current_folder2 = str(folder2_path) if folder2_path is not None else ''
    # If files changed since last verification, clear the verified flag
    if st.session_state.get('folder1_verified', '') != current_folder1 or st.session_state.get(
            'folder2_verified', '') != current_folder2:
        # Only clear the generation flag if the stored verification does not match current selection
        st.session_state['file_report_generation'] = False

    if st.session_state.get('file_report_generation') and st.session_state.get(
            'folder1_verified') == current_folder1 and st.session_state.get(
            'folder2_verified') == current_folder2:
        st.success('Both files verified')
    else:
        if folder1_path and folder2_path:
            col1, col2, col3, col4, col5, col6, col7, col8, col9 = st.columns(9)
            with col5:
                if st.button('Upload File and Verify'):
                    st.session_state['file_report_generation'] = True
                    st.session_state['folder1_verified'] = current_folder1
                    st.session_state['folder2_verified'] = current_folder2
                    st.success('Both files verified')
        else:
            col1, col2, col3, col4, col5, col6, col7, col8, col9 = st.columns(9)
            with col5:
                st.button('Upload File and Verify ', disabled=True)

    st.markdown('---')

    # Conversion of PSV file to DataFrame and Excel file to DataFrame using regression_generator functions to keep behavior consistent.
    # Conver PSV file into DataFrame and store into df1 and Excel file into DataFrame and store into df2.
    # In PSV Files, there are some meta data information in starting of file and then after some line data starts, so we need to skip that meta data information and then convert remaining data into DataFrame, for that we are using load_psv_for_display function which will automatically detect the line number from where data starts and then convert that data into DataFrame df1.
    # Excel File consist of 2 or more than 2 columns, First column consist of Reference Column name of PSV file and second column or 3rd or 4th ans so on, columns consist of value which we want to replace, these columns we can called as Targeted Columns in PSV file, so we need to read that Excel file and convert that into DataFrame df2, for that we are using pandas read_excel function.
    # Load PSV and Excel into DataFrames. Use defensive fallbacks so UI stays responsive even if reads fail.
    df1 = None
    df2 = None
    try:
        if 'folder1_path' in locals() and folder1_path:
            p1 = Path(folder1_path)
            if p1.exists() and p1.suffix.lower() == '.psv':
                try:
                    # primary reader: skip metadata and return a DataFrame
                    df1 = load_psv_for_display(p1)
                except Exception:
                    try:
                        df1 = load_psv_for_display(p1)
                    except Exception:
                        df1 = pd.DataFrame()
            else:
                df1 = pd.DataFrame()
        else:
            df1 = pd.DataFrame()
    except Exception:
        df1 = pd.DataFrame()

    try:
        if 'folder2_path' in locals() and folder2_path:
            p2 = Path(folder2_path)
            if p2.exists() and p2.suffix.lower() in ('.xls', '.xlsx', '.csv'):
                try:
                    if p2.suffix.lower() == '.csv':
                        df2 = pd.read_csv(p2, dtype=str, keep_default_na=False, encoding='utf-8', engine='python')
                    else:
                        df2 = pd.read_excel(p2, dtype=str)
                    df2 = df2.fillna('').astype(str)
                except Exception:
                    df2 = pd.DataFrame()
            else:
                df2 = pd.DataFrame()
        else:
            df2 = pd.DataFrame()
    except Exception:
        df2 = pd.DataFrame()

    # Validate Reference & Targetted columns of Excel File data frame should be available in PSV dataframe as well.
    st.markdown('---')


    # Show df1 onto UI
    # Profiling and DataFrame display (only shown after user clicks EDA Insight)
    st.subheader("*** Input Dataframe from PSV File ***")
    # Display only columns and their values. Avoid showing DataFrame index numbers.
    if df1 is None or (isinstance(df1, pd.DataFrame) and df1.empty):
        st.info('Loaded dataframe is empty.')
    else:
        # Use a scrollable dataframe display and hide the index for a clean look.
        # Calculate a height so approximately 10 rows are visible (row height estimate ~28px)
        nrows = min(len(df1), 10)
        # header + padding estimate added
        height = max(200, int(nrows * 28) + 80)
        try:
            # Render the DataFrame as an HTML table inside a fixed-height scrollable div
            # to ensure the table area has its own scrollbar and the index is not shown.
            df_html = df1.to_html(index=False, classes='dataframe', border=0)
            # Basic dark-theme friendly table styling; adjust colors as needed
            style = f"""
                        <style>
                        .dataframe {{border-collapse: collapse; width: 100%;}}
                        .dataframe th, .dataframe td {{padding: 6px 8px; border-bottom: 1px solid rgba(255,255,255,0.06); color: #e6e6e6;}}
                        .dataframe thead th {{position: sticky; top: 0; background: rgba(0,0,0,0.6); z-index: 2;}}
                        </style>
                        """
            html = f"{style}<div style='height:{height}px; overflow:auto;'>{df_html}</div>"
            components.html(html, height=height, scrolling=True)
        except Exception:
            # Fallback: convert to records and render; Streamlit may show index in edge cases
            records = df1.to_dict(orient='records')
            st.table(records)
    st.markdown('---')
    # Show df2 onto UI
    # Profiling and DataFrame display (only shown after user clicks EDA Insight)
    st.subheader("*** Input Dataframe from Excel File ***")
    # Display only columns and their values. Avoid showing DataFrame index numbers.
    if df2 is None or (isinstance(df2, pd.DataFrame) and df2.empty):
        st.info('Loaded dataframe is empty.')
    else:
        # Use a scrollable dataframe display and hide the index for a clean look.
        # Calculate a height so approximately 10 rows are visible (row height estimate ~28px)
        nrows = min(len(df2), 10)
        # header + padding estimate added
        height = max(200, int(nrows * 28) + 80)
        try:
            # Render the DataFrame as an HTML table inside a fixed-height scrollable div
            # to ensure the table area has its own scrollbar and the index is not shown.
            df_html = df2.to_html(index=False, classes='dataframe', border=0)
            # Basic dark-theme friendly table styling; adjust colors as needed
            style = f"""
                            <style>
                            .dataframe {{border-collapse: collapse; width: 100%;}}
                            .dataframe th, .dataframe td {{padding: 6px 8px; border-bottom: 1px solid rgba(255,255,255,0.06); color: #e6e6e6;}}
                            .dataframe thead th {{position: sticky; top: 0; background: rgba(0,0,0,0.6); z-index: 2;}}
                            </style>
                            """
            html = f"{style}<div style='height:{height}px; overflow:auto;'>{df_html}</div>"
            components.html(html, height=height, scrolling=True)
        except Exception:
            # Fallback: convert to records and render; Streamlit may show index in edge cases
            records = df2.to_dict(orient='records')
            st.table(records)
    st.markdown('---')

    # Create "Modify" Button and Post clicking on Modify button PSV files values should be changed as per values given in Excel.
    # Excel File Consist of 2 or more than 2 columns, First column consist of Reference Column name of PSV file and second column or 3rd or 4th ans so on, columns consist of value which we want to replace, these columns we can called as Targeted Columns in PSV file.
    # Create Final_Dataframe , then copy all PSV data frame into final_dataframe.
    # So according to above statement, we need to replace values of Targeted Columns in PSV file with values given in Excel file, but replacement should be done only when Reference Column name of Excel file matches with column name of PSV file, and this replacement should be done in final_dataframe for all rows of PSV file, and after successful replacement we can called that PSV file is modified as per Excel file.
    # After modification in final_Dataframe, we need to save that final_dataframe into new PSV file and that file we can called as Modified PSV file, and this Modified PSV file should be saved into reports folder of REPORTS_ROOT with name "Modified_{Origonal_PSV_FileName}_{timestamp).psv".
    # User should able to download that Modified PSV file and that file should be in PSV format only, and when user open that file, it should have same structure as original PSV file but values should be replaced as per Excel file.
    st.markdown('---')

    # Implement Modify action
    modified_path = None
    if st.button('Modify PSV using Excel'):
        # Basic validations
        if df1 is None or df1.empty:
            st.error('No PSV data loaded to modify.')
        elif df2 is None or df2.empty:
            st.error('No Excel replacement data loaded.')
        else:
            # Expect first column of df2 to be reference column name (values correspond to PSV key)
            ref_col_name = str(df2.columns[0]).strip()
            if ref_col_name not in df1.columns:
                st.error(f"Reference column '{ref_col_name}' from Excel not found in PSV columns.")
            else:
                # Determine target columns in df2 (remaining columns)
                target_cols = [c for c in df2.columns[1:]]
                if not target_cols:
                    st.error('Excel must contain at least one target column (column 2+ with replacement values).')
                else:
                    # Only keep target columns that exist in PSV; warn if some don't
                    existing_targets = [c for c in target_cols if c in df1.columns]
                    missing_targets = [c for c in target_cols if c not in df1.columns]
                    if missing_targets:
                        st.warning(f"Some target columns from Excel not present in PSV and will be skipped: {missing_targets}")

                    try:
                        # Use normalized replacement helper which matches case-insensitively with whitespace trimmed
                        final_df = apply_replacements(df1, df2, ref_col_name)

                        # Save preserving preamble/header where possible
                        if 'folder1_path' in locals() and folder1_path:
                            orig_name = Path(folder1_path).name
                            orig_path = Path(folder1_path)
                        else:
                            orig_name = 'original.psv'
                            orig_path = None

                        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                        out_name = f"Modified_{Path(orig_name).stem}_{timestamp}.psv"
                        REPORTS_ROOT.mkdir(parents=True, exist_ok=True)
                        modified_path = REPORTS_ROOT / out_name

                        # If we have original PSV, preserve preamble and header
                        if orig_path is not None and orig_path.exists():
                            write_psv_with_preamble(orig_path, final_df, modified_path)
                        else:
                            # fallback: write simple PSV
                            final_df.to_csv(modified_path, sep='|', index=False, na_rep='')

                        st.success(f'Modified PSV written to {modified_path}')
                    except Exception as e:
                        st.error(f'Failed to modify PSV: {e}')

    # If a modification was created previously in this session, show download button
    if modified_path is None:
        # try to find the latest modified file in REPORTS_ROOT matching Modified_ prefix
        try:
            files = sorted(REPORTS_ROOT.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
            for f in files:
                if f.is_file() and f.name.startswith('Modified_') and f.suffix.lower() == '.psv':
                    modified_path = f
                    break
        except Exception:
            modified_path = None

    if modified_path is not None and modified_path.exists():
        try:
            with open(modified_path, 'rb') as fh:
                data = fh.read()
            st.download_button(label='Download Modified PSV', data=data, file_name=modified_path.name, mime='text/plain')
        except Exception as e:
            st.error(f'Failed to prepare download: {e}')


    # End of view()

