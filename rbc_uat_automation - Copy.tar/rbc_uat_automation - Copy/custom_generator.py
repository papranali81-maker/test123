import re
import shutil
import tarfile
import tempfile
import zipfile
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple, Dict

import pandas as pd
import streamlit as st
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Side

from utility import _ensure_dirs, _recent_files, _validate_ccms_filename, _validate_cms_filename, \
    _validate_cnb_filename, _save_uploaded

# ==========================================================
# Base directory (works even if you run from elsewhere)
# ==========================================================

ROOT = Path(__file__).resolve().parent
DATA_ROOT = ROOT / 'data' / 'custom_generator'
UPLOADED_CC = DATA_ROOT / 'Uploaded_files' / 'ccms'
UPLOADED_CMS = DATA_ROOT / 'Uploaded_files' / 'cms'
UPLOADED_CNB = DATA_ROOT / 'Uploaded_files' / 'cnb'
EXTRACTED = DATA_ROOT / 'Extracted_psv_files'
EXTRACTED.mkdir(parents=True, exist_ok=True)
EXTRACTED_CC = DATA_ROOT / 'Extracted_psv_files'/ 'ccms'
EXTRACTED_CMS = DATA_ROOT / 'Extracted_psv_files'/ 'cms'
EXTRACTED_CNB = DATA_ROOT / 'Extracted_psv_files'/ 'cnb'
REPORTS_ROOT = ROOT / 'reports' / 'custom_generator'
REPORTS_ROOT.mkdir(parents=True, exist_ok=True)
REPORTS_CC = REPORTS_ROOT / 'ccms'
REPORTS_CC.mkdir(parents=True, exist_ok=True)
REPORTS_CMS = REPORTS_ROOT / 'cms'
REPORTS_CMS.mkdir(parents=True, exist_ok=True)
REPORTS_CNB = REPORTS_ROOT / 'cnb'
REPORTS_CNB.mkdir(parents=True, exist_ok=True)

# try to reuse readers from regression_generator if available
try:
    from regression_generator import _find_inner_out_tar, read_psv_preserve_shape, _read_psv_skip_meta, read_facility_psv_smart
except Exception:
    _find_inner_out_tar = None

_module_to_extracted = {
    'ccms': EXTRACTED_CC,
    'cms': EXTRACTED_CMS,
    'cnb': EXTRACTED_CNB,
}


def _extract_psvs_to_extracted(tar_path: Path, module: str) -> List[Path]:
    out_dir = _module_to_extracted.get(module)
    if out_dir is None:
        raise ValueError(f'Unknown module {module}')
    if out_dir.exists():
        for p in out_dir.iterdir():
            try:
                if p.is_file():
                    p.unlink()
                else:
                    shutil.rmtree(p)
            except Exception:
                pass
    out_dir.mkdir(parents=True, exist_ok=True)
    if tar_path is None:
        return []
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        try:
            with tarfile.open(tar_path) as t:
                t.extractall(path=tmp)
        except Exception:
            raise
        inner_tar = None
        if _find_inner_out_tar is not None:
            inner_tar = _find_inner_out_tar(tmp, module + '_out')
            if inner_tar is None:
                for kw in ['esn_out', 'cms_out', 'lgd_commercial', 'ccms_out', 'cnb_out']:
                    inner_tar = _find_inner_out_tar(tmp, kw)
                    if inner_tar:
                        break
        extract_root = tmp
        if inner_tar is not None:
            extract_root = tmp / 'inner'
            extract_root.mkdir(exist_ok=True)
            try:
                with tarfile.open(inner_tar) as it:
                    it.extractall(path=extract_root)
            except Exception:
                extract_root = tmp
        found = []
        for p in extract_root.rglob('*.psv'):
            try:
                dest = out_dir / p.name
                shutil.copy2(p, dest)
                found.append(dest)
            except Exception:
                continue
        return found


def _strip_timestamp_from_token(tok: Optional[str]) -> Optional[str]:
    if tok is None:
        return None
    if '{*}' in tok:
        return tok.replace('_{*}', '')
    m = re.match(r'^(.*?)(_\d{6,}.*)$', tok)
    if m:
        return m.group(1)
    return tok


def _find_psv_for_token(token: str, module: str) -> Optional[Path]:
    out_dir = _module_to_extracted.get(module)
    if out_dir is None or not out_dir.exists():
        return None
    stem = token
    candidate = out_dir / (stem + '.psv')
    if candidate.exists():
        return candidate
    base = _strip_timestamp_from_token(token)
    candidates = list(out_dir.glob('*.psv'))
    starts_token = [p for p in candidates if p.stem.startswith(stem)]
    if starts_token:
        starts_token.sort(key=lambda p: len(p.stem), reverse=True)
        return starts_token[0]
    starts_base = [p for p in candidates if p.stem.startswith(base)]
    if starts_base:
        starts_base.sort(key=lambda p: len(p.stem), reverse=True)
        return starts_base[0]
    contains_base = [p for p in candidates if base in p.stem]
    if contains_base:
        contains_base.sort(key=lambda p: len(p.stem), reverse=True)
        return contains_base[0]
    return None


def _parse_simple_sql(sql_text: str) -> Dict:
    txt = sql_text.strip().rstrip(';')
    txt = re.sub(r'\s+', ' ', txt)
    pat = re.match(r'(?i)SELECT (.*?) FROM (.*)', txt, flags=re.IGNORECASE)
    if not pat:
        return {'selects': [], 'from': None, 'joins': []}
    select_part = pat.group(1).strip()
    rest = pat.group(2).strip()
    cols = [c.strip() for c in re.split(r',\s*(?![^()]*\))', select_part) if c.strip()]
    selects = []
    for c in cols:
        m = re.match(r'(.+?)\s+AS\s+(.+)', c, flags=re.IGNORECASE)
        if m:
            left = m.group(1).strip()
            alias = m.group(2).strip()
        else:
            left = c
            alias = None
        parts = left.split('.')
        if len(parts) >= 2:
            table = parts[0].strip()
            column = parts[-1].strip()
        else:
            table = None
            column = left.strip()
        selects.append({'table': table, 'column': column, 'alias': alias})
    joins = []
    parts = re.split(r'(?i)\sLEFT\s+JOIN\s', rest)
    first = parts[0].strip()
    if first.upper().startswith('FROM '):
        first = first[5:].strip()
    m2 = re.match(r'([\w_{}*]+)', first)
    from_token = m2.group(1) if m2 else None
    for p in parts[1:]:
        m3 = re.match(r'([\w_{}*]+)\s+ON\s+(.*)', p, flags=re.IGNORECASE)
        if not m3:
            continue
        right_table = m3.group(1).strip()
        on_clause = m3.group(2).strip()
        conds = [cc.strip() for cc in re.split(r'(?i)\s+AND\s+', on_clause) if cc.strip()]
        on_pairs = []
        for cond in conds:
            mm = re.match(r'([\w_.{}*]+)\s*=\s*([\w_.{}*]+)', cond)
            if mm:
                leftq = mm.group(1).strip()
                rightq = mm.group(2).strip()
                on_pairs.append((leftq, rightq))
        joins.append({'right_table': right_table, 'on': on_pairs, 'type': 'LEFT'})
    return {'selects': selects, 'from': from_token, 'joins': joins}


def _load_psvs_for_sql(parsed: Dict, module: str) -> Tuple[Dict[str, pd.DataFrame], List[str], List[str]]:
    df_map = {}
    missing_files = []
    missing_columns = []
    tables = []
    if parsed.get('from'):
        tables.append(parsed['from'])
    for j in parsed.get('joins', []):
        tables.append(j.get('right_table'))
    seen = set()
    tables = [t for t in tables if t and not (t in seen or seen.add(t))]
    for t in tables:
        p = _find_psv_for_token(t, module)
        if p is None:
            missing_files.append(t)
            continue
        try:
            if 'facility' in p.stem.lower():
                df = read_facility_psv_smart(p) if 'read_facility_psv_smart' in globals() else _read_psv_skip_meta(p)
            else:
                df = _read_psv_skip_meta(p) if '_read_psv_skip_meta' in globals() else read_psv_preserve_shape(p)
        except Exception:
            try:
                df = read_psv_preserve_shape(p) if 'read_psv_preserve_shape' in globals() else _read_psv_skip_meta(p)
            except Exception:
                missing_files.append(t)
                continue
        key = _strip_timestamp_from_token(t)
        df_map[key] = df
    required_cols = set()
    for sel in parsed.get('selects', []):
        if sel.get('column'):
            required_cols.add(sel.get('column'))
    for j in parsed.get('joins', []):
        for l, r in j.get('on', []):
            lc = l.split('.')[-1]
            rc = r.split('.')[-1]
            required_cols.add(lc)
            required_cols.add(rc)
    for rc in required_cols:
        found_any = False
        for df in df_map.values():
            if any(str(c).strip().lower() == rc.strip().lower() for c in df.columns):
                found_any = True
                break
        if not found_any:
            missing_columns.append(rc)
    return df_map, missing_files, missing_columns


def _execute_parsed_sql(parsed: Dict, df_map: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    if parsed.get('from') is None:
        return pd.DataFrame()
    from_tok = _strip_timestamp_from_token(parsed['from'])
    if from_tok not in df_map:
        keys = list(df_map.keys())
        if keys:
            from_tok = keys[0]
        else:
            return pd.DataFrame()
    prefixed = {}
    for k, df in df_map.items():
        mapping = {col: f"{k}__{col}" for col in df.columns}
        prefixed[k] = df.rename(columns=mapping).copy()
    result = prefixed[from_tok].copy()
    for j in parsed.get('joins', []):
        right_raw = j.get('right_table')
        right_key = _strip_timestamp_from_token(right_raw)
        if right_key not in prefixed:
            right_key = next((x for x in prefixed.keys() if x.startswith(right_key)), None)
        if right_key is None:
            continue
        right_df = prefixed[right_key]
        left_on = []
        right_on = []
        for lq, rq in j.get('on', []):
            lparts = lq.split('.')
            rparts = rq.split('.')
            ltab = _strip_timestamp_from_token(lparts[0]) if len(lparts) > 1 else from_tok
            rtab = _strip_timestamp_from_token(rparts[0]) if len(rparts) > 1 else right_key
            lcol = lparts[-1]
            rcol = rparts[-1]
            left_on.append(f"{ltab}__{lcol}")
            right_on.append(f"{rtab}__{rcol}")
        valid_left = []
        valid_right = []
        for lo, ro in zip(left_on, right_on):
            if lo in result.columns and ro in right_df.columns:
                valid_left.append(lo)
                valid_right.append(ro)
        try:
            if valid_left and len(valid_left) == len(valid_right):
                result = result.merge(right_df, left_on=valid_left, right_on=valid_right, how='left')
            else:
                common = []
                left_cols = {c.split('__')[-1].lower(): c for c in result.columns}
                right_cols = {c.split('__')[-1].lower(): c for c in right_df.columns}
                for colname, lfull in left_cols.items():
                    if colname in right_cols:
                        common.append((lfull, right_cols[colname]))
                if common:
                    left_list = [pair[0] for pair in common]
                    right_list = [pair[1] for pair in common]
                    result = result.merge(right_df, left_on=left_list, right_on=right_list, how='left')
                else:
                    result = pd.concat([result.reset_index(drop=True), right_df.reset_index(drop=True)], axis=1)
        except Exception:
            result = pd.concat([result.reset_index(drop=True), right_df.reset_index(drop=True)], axis=1)
    final_cols = []
    final_rename = {}
    seen_names = {}
    for sel in parsed.get('selects', []):
        table_tok = sel.get('table')
        col = sel.get('column')
        alias = sel.get('alias')
        if table_tok:
            key = _strip_timestamp_from_token(table_tok)
            candidate = f"{key}__{col}"
            if candidate not in result.columns:
                matches = [c for c in result.columns if c.lower().endswith('__' + col.lower())]
                candidate = matches[0] if matches else None
        else:
            matches = [c for c in result.columns if c.lower().endswith('__' + col.lower()) or c.lower() == col.lower()]
            candidate = matches[0] if matches else None
        if candidate is None:
            fake = f'__MISSING__{col}'
            result[fake] = ''
            final_cols.append(fake)
            final_rename[fake] = alias or col
            continue
        final_cols.append(candidate)
        display = alias or col
        if display in seen_names:
            display = f"{table_tok}_{display}" if table_tok else f"{display}_{seen_names[display]+1}"
            seen_names[display] = seen_names.get(display, 0) + 1
        else:
            seen_names[display] = 1
        final_rename[candidate] = display
    df_final = result.loc[:, final_cols].copy()
    df_final = df_final.rename(columns=final_rename)
    return df_final


def _export_df_to_excel(df: pd.DataFrame, module: str, report_dir: Path) -> Path:
    report_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    out_xlsx = report_dir / f'{module.lower()}_custom_report_{ts}.xlsx'
    sheet_name = f"{module.upper()}_Custom"
    with pd.ExcelWriter(out_xlsx, engine='openpyxl') as writer:
        if df is None or df.empty:
            pd.DataFrame().to_excel(writer, sheet_name=sheet_name, index=False)
        else:
            df.to_excel(writer, sheet_name=sheet_name, index=False)
    wb = load_workbook(out_xlsx)
    ws = wb[sheet_name]
    center = Alignment(horizontal='center', vertical='center', wrap_text=False)
    thin = Side(border_style="thin", color="000000")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=ws.max_column):
        for cell in row:
            if cell.value is None:
                cell.value = ''
            cell.alignment = center
            cell.border = border
    wb.save(out_xlsx)
    return out_xlsx


def _zip_report_files(paths: List[Path], out_zip: Path) -> Path:
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_zip, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for p in paths:
            z.write(p, arcname=p.name)
    return out_zip


@contextmanager
def _st_spinner(message: str):
    """Safe contextmanager wrapper around streamlit.spinner to satisfy type checkers."""
    with st.spinner(message):
        yield


# --- SQL normalization: convert numeric timestamp tokens to _{*} ---
def normalize_sql_timestamps(sql_text: str) -> str:
    """Normalize tokens in SQL that contain long numeric timestamp suffixes into the placeholder _{*}.
    Example: Facility_cnb_out_20250403_202505232005 -> Facility_cnb_out_{*}
    The regex looks for an identifier followed by an underscore and a 6+ digit group (timestamp-like).
    """
    if not sql_text:
        return sql_text
    # Replace occurrences inside tokens. We avoid touching numeric literals by focusing on word-like tokens.
    # Pattern: capture a token that ends with _<digits>[_digits...], replace trailing numeric part with _{*}
    pattern = re.compile(r'([A-Za-z0-9]+(?:_[A-Za-z0-9]+)*?)_(\d{6,}(?:[_\d]*\d)?)')
    def _repl(m):
        return f"{m.group(1)}_{{*}}"
    return pattern.sub(_repl, sql_text)

# Streamlit on_change callbacks to auto-normalize pasted SQL into session_state (custom-scoped)
def _normalize_ccms_sql_callback():
    val = st.session_state.get('custom_ccms_sql', '')
    norm = normalize_sql_timestamps(val)
    if norm != val:
        st.session_state['custom_ccms_sql'] = norm

def _normalize_cms_sql_callback():
    val = st.session_state.get('custom_cms_sql', '')
    norm = normalize_sql_timestamps(val)
    if norm != val:
        st.session_state['custom_cms_sql'] = norm

def _normalize_cnb_sql_callback():
    val = st.session_state.get('custom_cnb_sql', '')
    norm = normalize_sql_timestamps(val)
    if norm != val:
        st.session_state['custom_cnb_sql'] = norm

# --- Fallback PSV readers if regression_generator readers are not available ---
if 'read_psv_preserve_shape' not in globals():
    def read_psv_preserve_shape(p: Path) -> pd.DataFrame:
        # Simple PSV reader that preserves all columns and reads as strings; strips no metadata lines except blank first line
        try:
            # try to detect and skip a metadata first line if it starts with '#' or '##' or 'Metadata' or similar
            with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                first = f.readline()
                rest = f.read()
            # Heuristic: if first line contains non-pipe characters and not contains '|' assume metadata
            if '|' not in first and len(first.strip()) > 0:
                # recreate temp content without first line
                from io import StringIO
                sio = StringIO(rest)
                df = pd.read_csv(sio, sep='|', dtype=str, engine='python')
            else:
                from io import StringIO
                sio = StringIO(first + rest)
                df = pd.read_csv(sio, sep='|', dtype=str, engine='python')
        except Exception:
            # fallback: try pandas read_table
            df = pd.read_csv(p, sep='|', dtype=str, engine='python', on_bad_lines='skip')
        # Ensure columns are strings
        df.columns = [str(c) for c in df.columns]
        return df

if '_read_psv_skip_meta' not in globals():
    def _read_psv_skip_meta(p: Path) -> pd.DataFrame:
        # Similar behaviour: skip first line if it doesn't contain the pipe separator
        try:
            with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
            if lines and '|' not in lines[0]:
                data = ''.join(lines[1:])
            else:
                data = ''.join(lines)
            from io import StringIO
            sio = StringIO(data)
            df = pd.read_csv(sio, sep='|', dtype=str, engine='python')
        except Exception:
            df = pd.DataFrame()
        df.columns = [str(c) for c in df.columns]
        return df

if 'read_facility_psv_smart' not in globals():
    def read_facility_psv_smart(p: Path) -> pd.DataFrame:
        # For facility, use the same reader but ensure some common facility columns exist
        df = read_psv_preserve_shape(p)
        return df

def _reset_custom_state():
    """Reset Streamlit session state items related to custom generation so the user can start fresh.

    Avoid setting file_uploader-backed keys (e.g. 'ccms_upload') because Streamlit will raise if they are set.
    """
    keys_defaults = {
        # readiness flags
        'custom_ccms_ready': False,
        'custom_cms_ready': False,
        'custom_cnb_ready': False,
        # verification/report flags
        'ccms_report_generation': False,
        'cms_report_generation': False,
        'cnb_report_generation': False,
        # SQL storage (normalized queries) and parsed structures
        'ccms_sql_query': '',
        'cms_sql_query': '',
        'cnb_sql_query': '',
        'ccms_sql_parsed': None,
        'cms_sql_parsed': None,
        'cnb_sql_parsed': None,
        # matched mapping shown in UI
        'ccms_matched_map': {},
        'cms_matched_map': {},
        'cnb_matched_map': {},
        # custom-scoped textareas and selects (do not touch consolidated page keys)
        'custom_ccms_sql': '',
        'custom_cms_sql': '',
        'custom_cnb_sql': '',
         'ccms_select': '',
         'cms_select': '',
         'cnb_select': '',
        # locked flags for SQL editing (custom-scoped)
        'custom_ccms_sql_locked': False,
        'custom_cms_sql_locked': False,
        'custom_cnb_sql_locked': False,
    }
    for k, v in keys_defaults.items():
        st.session_state[k] = v



# Streamlit view for custom generator

def view():
    # Ensure required folders(uploads, reports) exist on Root
    _ensure_dirs([UPLOADED_CC, UPLOADED_CMS, UPLOADED_CNB, EXTRACTED, EXTRACTED_CC, EXTRACTED_CMS, EXTRACTED_CNB, REPORTS_CC, REPORTS_CMS, REPORTS_CNB])

    st.markdown("# LGD UAT Automation Solution", text_alignment="center")
    st.title('Custom Report Generator', text_alignment="center")
    st.caption('Upload or Select CCMS/CMS/CNB TAR files & paste SQL for CCMS/CMS/CNB to generate Custom reports', text_alignment="center")

    # Mark that we are on the Custom page so other parts of app can detect it
    st.session_state['home_custom'] = True

    # Refresh button for consolidated page (top-right of CCMS section)
    if st.button('Refresh', key='refresh_top'):
        _reset_custom_state()
        rerun = getattr(st, 'experimental_rerun', None)
        if callable(rerun):
            try:
                rerun()
            except Exception:
                pass

    if 'custom_ccms_ready' not in st.session_state:
        st.session_state['custom_ccms_ready'] = False
    if 'custom_cms_ready' not in st.session_state:
        st.session_state['custom_cms_ready'] = False
    if 'custom_cnb_ready' not in st.session_state:
        st.session_state['custom_cnb_ready'] = False

    # SQL input defaults (use custom-scoped keys so they don't interfere with consolidated page)
    if 'custom_ccms_sql' not in st.session_state:
        st.session_state['custom_ccms_sql'] = ''
    if 'custom_cms_sql' not in st.session_state:
        st.session_state['custom_cms_sql'] = ''
    if 'custom_cnb_sql' not in st.session_state:
        st.session_state['custom_cnb_sql'] = ''
    # locked flags indicate the SQL textarea should be made read-only after Verify (custom-scoped)
    if 'custom_ccms_sql_locked' not in st.session_state:
        st.session_state['custom_ccms_sql_locked'] = False
    if 'custom_cms_sql_locked' not in st.session_state:
        st.session_state['custom_cms_sql_locked'] = False
    if 'custom_cnb_sql_locked' not in st.session_state:
        st.session_state['custom_cnb_sql_locked'] = False

    # CCMS
    st.subheader('CCMS Section:---')
    ccms_select = st.selectbox('Select CCMS TAR File', options=[''] + _recent_files(UPLOADED_CC), key='ccms_select')
    ccms_upload = st.file_uploader('Or Upload CCMS TAR File', type=['tar', 'gz'],key='ccms_upload')
    ccms_path = None
    if ccms_upload is not None:
        if not _validate_ccms_filename(ccms_upload.name):
            st.error("Please upload 'lgd_ccms_in_out_{timestamp}.tar.gz' or 'ccms_out_{timestamp}.tar.gz'")
        else:
            ccms_path = _save_uploaded(ccms_upload, UPLOADED_CC)
            st.success(f'Uploaded to {ccms_path}')
    elif ccms_select:
        ccms_path = UPLOADED_CC / ccms_select

    # SQL input from user (editable)
    st.markdown('**CCMS SQL (Editable)**')
    # Use custom-scoped key so it doesn't conflict with consolidated page
    st.text_area('Type or Paste CCMS SQL here', key='custom_ccms_sql', height=220, on_change=_normalize_ccms_sql_callback, disabled=st.session_state.get('custom_ccms_sql_locked', False))

    current_ccms = str(ccms_path) if ccms_path is not None else ''
    # Enable Verify only when both TAR is selected/uploaded and SQL text is non-empty
    ccms_sql_text = st.session_state.get('custom_ccms_sql','').strip()
    if ccms_path and ccms_sql_text:
        cols = st.columns(9)
        with cols[4]:
            if st.button('Upload File and Verify (CCMS)', key='verify_ccms'):
                # Extract PSV files first
                with _st_spinner(f'Extracting PSV files from {ccms_path}'):
                    _extract_psvs_to_extracted(ccms_path, 'ccms')
                # Normalize and parse the user-provided SQL and store it
                norm_sql = normalize_sql_timestamps(ccms_sql_text)
                parsed = _parse_simple_sql(norm_sql)
                # Pre-load referenced PSVs to check for missing files/columns
                df_map, missing_files, missing_cols = _load_psvs_for_sql(parsed, 'ccms')
                # persist mapping and show in an expander table
                try:
                    matched_map = _matched_psv_paths(parsed, 'ccms')
                    token_rows = []
                    map_dict = {}
                    for t, p in matched_map.items():
                        fn = p.name if p is not None else None
                        token_rows.append({'token': t, 'matched_filename': fn or 'NOT FOUND'})
                        map_dict[t] = fn
                    st.session_state['ccms_matched_map'] = map_dict
                except Exception:
                    pass
                if missing_files or missing_cols:
                    st.warning(f'CCMS verification found missing inputs: files={missing_files} cols={missing_cols}')
                    st.session_state['custom_ccms_ready'] = False
                else:
                    # store normalized SQL into a separate key and lock editing; keep textarea key untouched
                    st.session_state['ccms_sql_query'] = norm_sql
                    st.session_state['ccms_sql_parsed'] = parsed
                    st.session_state['custom_ccms_sql_locked'] = True
                    st.session_state['custom_ccms_ready'] = True
                    st.success('CCMS files verified')
                # Left-aligned display of matched files (use persisted session state)
                if st.session_state.get('ccms_matched_map'):
                    try:
                        token_rows_display = [{'token': t, 'matched_filename': (fn or 'NOT FOUND')} for t, fn in st.session_state.get('ccms_matched_map', {}).items()]
                        with st.expander('Matched PSV files (token -> filename)', expanded=False):
                            import pandas as _pd
                            st.table(_pd.DataFrame(token_rows_display))
                    except Exception:
                        for t, fn in st.session_state.get('ccms_matched_map', {}).items():
                            st.write(f"{t}  ->  {fn or 'NOT FOUND'}")
    else:
        cols = st.columns(9)
        with cols[4]:
            # show disabled button with helpful message when missing inputs
            if not ccms_path:
                st.button('Upload File and Verify (CCMS)', disabled=True, key='verify_ccms_disabled')
            else:
                # TAR present but no SQL yet
                st.button('Upload File and Verify (CCMS)', disabled=True, key='verify_ccms_disabled')

    st.markdown('---')

    # CMS
    st.subheader('CMS Section:---')
    cms_select = st.selectbox('Select CMS TAR File', options=[''] + _recent_files(UPLOADED_CMS), key='cms_select')
    cms_upload = st.file_uploader('Or Upload CMS TAR File', type=['tar', 'gz'], key='cms_upload')
    cms_path = None
    if cms_upload is not None:
        if not _validate_cms_filename(cms_upload.name):
            st.error("Please upload 'lgd_commercial_in_out_{timestamp}.tar.gz' or 'esn_out_{timestamp}.tar.gz' or 'cms_out_{timestamp}.tar.gz'")
        else:
            cms_path = _save_uploaded(cms_upload, UPLOADED_CMS)
            st.success(f'Uploaded to {cms_path}')
    elif cms_select:
        cms_path = UPLOADED_CMS / cms_select
    st.markdown('**CMS SQL (Editable)**')
    st.text_area('Type or Paste CMS SQL here', key='custom_cms_sql', height=220, on_change=_normalize_cms_sql_callback, disabled=st.session_state.get('custom_cms_sql_locked', False))
    if cms_path:
        cms_sql_text = st.session_state.get('custom_cms_sql','').strip()
        cols = st.columns(9)
        with cols[4]:
            if cms_path and cms_sql_text:
                if st.button('Upload File and Verify (CMS)', key='verify_cms'):
                    with _st_spinner(f'Extracting PSV files from {cms_path}'):
                        _extract_psvs_to_extracted(cms_path, 'cms')
                    norm_sql = normalize_sql_timestamps(cms_sql_text)
                    parsed = _parse_simple_sql(norm_sql)
                    st.session_state['cms_sql_query'] = norm_sql
                    st.session_state['cms_sql_parsed'] = parsed
                    df_map, missing_files, missing_cols = _load_psvs_for_sql(parsed, 'cms')
                    try:
                        matched_map = _matched_psv_paths(parsed, 'cms')
                        token_rows = []
                        map_dict = {}
                        for t, p in matched_map.items():
                            fn = p.name if p is not None else None
                            token_rows.append({'token': t, 'matched_filename': fn or 'NOT FOUND'})
                            map_dict[t] = fn
                        st.session_state['cms_matched_map'] = map_dict
                        with st.expander('Matched PSV files (token -> filename)', expanded=False):
                            try:
                                import pandas as _pd
                                st.table(_pd.DataFrame(token_rows))
                            except Exception:
                                for row in token_rows:
                                    st.write(f"{row['token']}  ->  {row['matched_filename']}")
                    except Exception:
                        pass
                    if missing_files or missing_cols:
                        st.warning(f'CMS verification found missing inputs: files={missing_files} cols={missing_cols}')
                        st.session_state['custom_cms_ready'] = False
                    else:
                        # store normalized query separately and lock editing of the custom textarea
                        st.session_state['cms_sql_query'] = norm_sql
                        st.session_state['cms_sql_parsed'] = parsed
                        st.session_state['custom_cms_sql_locked'] = True
                        st.session_state['custom_cms_ready'] = True
                        st.success('CMS files verified')
                    # left-aligned matched expander
                    if st.session_state.get('cms_matched_map'):
                        try:
                            token_rows_display = [{'token': t, 'matched_filename': (fn or 'NOT FOUND')} for t, fn in st.session_state.get('cms_matched_map', {}).items()]
                            with st.expander('Matched PSV files (token -> filename)', expanded=False):
                                for row in token_rows_display:
                                    fn = row.get('matched_filename') or 'NOT FOUND'
                                    st.markdown(f'- {fn}')
                        except Exception:
                            for t, fn in st.session_state.get('cms_matched_map', {}).items():
                                st.markdown(f'- {fn or "NOT FOUND"}')
    else:
        cols = st.columns(9)
        with cols[4]:
            st.button('Upload File and Verify (CMS)', disabled=True, key='verify_cms_disabled')

    st.markdown('---')

    # CNB
    st.subheader('CNB Section:---')
    cnb_select = st.selectbox('Select CNB TAR File', options=[''] + _recent_files(UPLOADED_CNB), key='cnb_select')
    cnb_upload = st.file_uploader('Or Upload CNB TAR File', type=['tar', 'gz'], key='cnb_upload')
    cnb_path = None
    if cnb_upload is not None:
        if not _validate_cnb_filename(cnb_upload.name):
            st.error("Please upload 'cnb_in_out_{timestamp}.tar.gz' or 'cnb_out_{timestamp}.tar.gz'")
        else:
            cnb_path = _save_uploaded(cnb_upload, UPLOADED_CNB)
            st.success(f'Uploaded to {cnb_path}')
    elif cnb_select:
        cnb_path = UPLOADED_CNB / cnb_select
    st.markdown('**CNB SQL (Editable)**')
    st.text_area('Type or Paste CNB SQL here', key='custom_cnb_sql', height=220, on_change=_normalize_cnb_sql_callback, disabled=st.session_state.get('custom_cnb_sql_locked', False))
    if cnb_path:
        cnb_sql_text = st.session_state.get('custom_cnb_sql','').strip()
        cols = st.columns(9)
        with cols[4]:
            if cnb_path and cnb_sql_text:
                if st.button('Upload File and Verify (CNB)', key='verify_cnb'):
                    with _st_spinner(f'Extracting PSV files from {cnb_path}'):
                        _extract_psvs_to_extracted(cnb_path, 'cnb')
                    norm_sql = normalize_sql_timestamps(cnb_sql_text)
                    parsed = _parse_simple_sql(norm_sql)
                    st.session_state['cnb_sql_query'] = norm_sql
                    st.session_state['cnb_sql_parsed'] = parsed
                    df_map, missing_files, missing_cols = _load_psvs_for_sql(parsed, 'cnb')
                    try:
                        matched_map = _matched_psv_paths(parsed, 'cnb')
                        token_rows = []
                        map_dict = {}
                        for t, p in matched_map.items():
                            fn = p.name if p is not None else None
                            token_rows.append({'token': t, 'matched_filename': fn or 'NOT FOUND'})
                            map_dict[t] = fn
                        st.session_state['cnb_matched_map'] = map_dict
                        with st.expander('Matched PSV files (token -> filename)', expanded=False):
                            try:
                                import pandas as _pd
                                st.table(_pd.DataFrame(token_rows))
                            except Exception:
                                for row in token_rows:
                                    st.write(f"{row['token']}  ->  {row['matched_filename']}")
                    except Exception:
                        pass
                    if missing_files or missing_cols:
                        st.warning(f'CNB verification found missing inputs: files={missing_files} cols={missing_cols}')
                        st.session_state['custom_cnb_ready'] = False
                    else:
                        st.session_state['cnb_sql_query'] = norm_sql
                        st.session_state['cnb_sql_parsed'] = parsed
                        st.session_state['custom_cnb_sql_locked'] = True
                        st.session_state['custom_cnb_ready'] = True
                        st.success('CNB files verified')
                    # left-aligned matched expander
                    if st.session_state.get('cnb_matched_map'):
                        try:
                            token_rows_display = [{'token': t, 'matched_filename': (fn or 'NOT FOUND')} for t, fn in st.session_state.get('cnb_matched_map', {}).items()]
                            with st.expander('Matched PSV files (token -> filename)', expanded=False):
                                for row in token_rows_display:
                                    fn = row.get('matched_filename') or 'NOT FOUND'
                                    st.markdown(f'- {fn}')
                        except Exception:
                            for t, fn in st.session_state.get('cnb_matched_map', {}).items():
                                st.markdown(f'- {fn or "NOT FOUND"}')
    else:
        cols = st.columns(9)
        with cols[4]:
            st.button('Upload File and Verify (CNB)', disabled=True, key='verify_cnb_disabled')

    st.markdown('---')

    if st.session_state.get('custom_ccms_ready') or st.session_state.get('custom_cms_ready') or st.session_state.get('custom_cnb_ready'):
        module_placeholders = {'ccms': st.empty(), 'cms': st.empty(), 'cnb': st.empty()}
        if st.button('Generate Custom Report', key='generate_custom'):
            reports_generated = []
            errors_found = []
            progress_bar = st.progress(0)
            status_box = st.empty()
            modules_to_run = []
            if st.session_state.get('custom_ccms_ready'):
                modules_to_run.append('ccms')
            if st.session_state.get('custom_cms_ready'):
                modules_to_run.append('cms')
            if st.session_state.get('custom_cnb_ready'):
                modules_to_run.append('cnb')
            progress_widgets = {}
            for mod in modules_to_run:
                container = module_placeholders[mod]
                container.markdown(f'**{mod.upper()} Report Progress:**')
                pb = container.progress(0)
                stbox = container.empty()
                progress_widgets[mod] = (pb, stbox)
            def make_cb(mod_name):
                def cb(pct, msg):
                    try:
                        try:
                            progress_bar.progress(min(max(int(pct), 0), 100))
                        except Exception:
                            pass
                        pair = progress_widgets.get(mod_name)
                        if pair:
                            pb, stbox = pair
                            try:
                                pb.progress(min(max(int(pct), 0), 100))
                            except Exception:
                                pass
                            try:
                                stbox.info(msg)
                            except Exception:
                                pass
                    except Exception:
                        pass
                return cb

            # run sequentially
            if st.session_state.get('custom_ccms_ready'):
                cb = make_cb('ccms')
                try:
                    cb(0, 'Starting CCMS custom generation')
                    # Prefer normalized verified query if present, else use the typed custom SQL
                    sql_text = st.session_state.get('ccms_sql_query') or st.session_state.get('custom_ccms_sql','')
                    sql_text = normalize_sql_timestamps(sql_text)
                    if not sql_text.strip():
                        errors_found.append('CCMS SQL is empty; skipping CCMS')
                    else:
                        cb(20, 'Parsing CCMS SQL')
                        parsed = _parse_simple_sql(sql_text)
                        cb(40, 'Loading CCMS PSV files')
                        df_map, missing_files, missing_cols = _load_psvs_for_sql(parsed, 'ccms')
                        if missing_files or missing_cols:
                            cb(60, 'Missing PSV files or columns for CCMS; skipping CCMS generation')
                            errors_found.append(f'CCMS missing inputs: files={missing_files} cols={missing_cols}')
                        else:
                            cb(80, 'Executing CCMS SQL joins')
                            df_final = _execute_parsed_sql(parsed, df_map)
                            cb(90, 'Exporting CCMS custom Excel')
                            out = _export_df_to_excel(df_final, 'ccms', REPORTS_CC)
                            reports_generated.append(out)
                            cb(100, 'CCMS generation completed')
                except Exception as e:
                    errors_found.append(f'CCMS error: {e}')

            if st.session_state.get('custom_cms_ready'):
                cb = make_cb('cms')
                try:
                    cb(0, 'Starting CMS custom generation')
                    sql_text = st.session_state.get('cms_sql_query') or st.session_state.get('custom_cms_sql','')
                    sql_text = normalize_sql_timestamps(sql_text)
                    if not sql_text.strip():
                        errors_found.append('CMS SQL is empty; skipping CMS')
                    else:
                        cb(20, 'Parsing CMS SQL')
                        parsed = _parse_simple_sql(sql_text)
                        cb(40, 'Loading CMS PSV files')
                        df_map, missing_files, missing_cols = _load_psvs_for_sql(parsed, 'cms')
                        if missing_files or missing_cols:
                            cb(60, 'Missing PSV files or columns for CMS; skipping CMS generation')
                            errors_found.append(f'CMS missing inputs: files={missing_files} cols={missing_cols}')
                        else:
                            cb(80, 'Executing CMS SQL joins')
                            df_final = _execute_parsed_sql(parsed, df_map)
                            cb(90, 'Exporting CMS custom Excel')
                            out = _export_df_to_excel(df_final, 'cms', REPORTS_CMS)
                            reports_generated.append(out)
                            cb(100, 'CMS generation completed')
                except Exception as e:
                    errors_found.append(f'CMS error: {e}')

            if st.session_state.get('custom_cnb_ready'):
                cb = make_cb('cnb')
                try:
                    cb(0, 'Starting CNB custom generation')
                    sql_text = st.session_state.get('cnb_sql_query') or st.session_state.get('custom_cnb_sql','')
                    sql_text = normalize_sql_timestamps(sql_text)
                    if not sql_text.strip():
                        errors_found.append('CNB SQL is empty; skipping CNB')
                    else:
                        cb(20, 'Parsing CNB SQL')
                        parsed = _parse_simple_sql(sql_text)
                        cb(40, 'Loading CNB PSV files')
                        df_map, missing_files, missing_cols = _load_psvs_for_sql(parsed, 'cnb')
                        if missing_files or missing_cols:
                            cb(60, 'Missing PSV files or columns for CNB; skipping CNB generation')
                            errors_found.append(f'CNB missing inputs: files={missing_files} cols={missing_cols}')
                        else:
                            cb(80, 'Executing CNB SQL joins')
                            df_final = _execute_parsed_sql(parsed, df_map)
                            cb(90, 'Exporting CNB custom Excel')
                            out = _export_df_to_excel(df_final, 'cnb', REPORTS_CNB)
                            reports_generated.append(out)
                            cb(100, 'CNB generation completed')
                except Exception as e:
                    errors_found.append(f'CNB error: {e}')

            if errors_found:
                for e in errors_found:
                    st.warning(e)
            if reports_generated:
                ts = datetime.now().strftime('%Y%m%d_%H%M%S')
                zip_path = REPORTS_ROOT / f'custom_report_{ts}.zip'
                _zip_report_files(reports_generated, zip_path)
                with open(zip_path, 'rb') as f:
                    data = f.read()
                col_dl, col_ref = st.columns([3,1])
                with col_dl:
                    st.download_button('Download Custom Reports ZIP', data, file_name=zip_path.name, key='download_custom_zip')

def _matched_psv_paths(parsed: Dict, module: str) -> Dict[str, Optional[Path]]:
    """Return a mapping from table token (as in SQL) to the matched Path in the extracted folder or None."""
    mapping: Dict[str, Optional[Path]] = {}
    if parsed is None:
        return mapping
    tokens = []
    if parsed.get('from'):
        tokens.append(parsed['from'])
    for j in parsed.get('joins', []):
        rt = j.get('right_table')
        if rt:
            tokens.append(rt)
    # unique preserve order
    seen = set()
    tokens = [t for t in tokens if t and not (t in seen or seen.add(t))]
    for t in tokens:
        p = _find_psv_for_token(t, module)
        mapping[t] = p
    return mapping
