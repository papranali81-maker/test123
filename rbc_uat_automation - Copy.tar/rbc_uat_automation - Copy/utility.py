from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parent
# --------------------------------------------------

def reset_session(preserve_keys: list = None):
    """Safely clear Streamlit session_state.
    - preserve_keys: optional list of keys to keep (e.g., {'mode'}).
    - After clearing, ensures 'mode' == 'Welcome' unless overridden in preserve_keys.
    - Does not call experimental_rerun; Streamlit will automatically rerun after button clicks.
    """
    import streamlit as st
    if preserve_keys is None:
        preserve_keys = []
    # capture values to preserve
    preserved = {k: st.session_state.get(k) for k in preserve_keys if k in st.session_state}
    # clear all keys
    for k in list(st.session_state.keys()):
        del st.session_state[k]
    # restore preserved keys
    for k, v in preserved.items():
        st.session_state[k] = v
    # ensure mode is Welcome
    if 'mode' not in st.session_state:
        st.session_state['mode'] = 'Welcome'


# --- Function: _ensure_dirs ---
# Purpose: Ensure required folders (uploads, reports) exist on Root
# Info: Called at startup and by the UI to prepare runtime folders
def _ensure_dirs(list_of_dirs: list):
    # Ensure folders exist
    for d in list_of_dirs:
        d.mkdir(parents=True, exist_ok=True)


# --- Function: _recent_files ---
# Purpose: Return a sorted list of most recent .tar* filenames in a folder
# Info: used to populate selectboxes for uploaded files in the Streamlit UI
def _recent_files(folder: Path, limit=5):
    if not folder.exists():
        return []
    files = sorted(folder.glob('*.tar*'), key=lambda p: p.stat().st_mtime, reverse=True)
    return [p.name for p in files[:limit]]


# --- Function: _validate_filename ---
def _validate_filename(name: str) -> bool:
    # Allowed prefixes for TAR files
    allowed_prefixes = (
        'lgd_ccms_in_out',
        'ccms_out',
        'ccms_in',
        'lgd_commercial_in_out',
        'esn_out',
        'cms_out',
        'cnb_in_out',
        'cnb_out',
        'cnb_in',
    )

    # Allow any Excel file
    if name.endswith('.xlsx'):
        return True

    # Allow TAR files only if they match allowed prefixes
    return name.startswith(allowed_prefixes) and (name.endswith('.tar.gz') or name.endswith('.tar'))


# --- Function: _validate_ccms_filename ---
# Purpose: Basic filename pattern check for CCMS tar archives
def _validate_ccms_filename(name: str) -> bool:
    return (name.startswith('lgd_ccms_in_out') or name.startswith('ccms_out')) and (name.endswith('.tar.gz') or name.endswith('.tar'))


# --- Function: _validate_cms_filename ---
# Purpose: Basic filename pattern check for CMS tar archives
# Info: allows common prefixes seen in repo (lgd_commercial_in_out, esn_out)
def _validate_cms_filename(name: str) -> bool:
    # allow two common prefixes seen in prompt
    return (name.startswith('lgd_commercial_in_out') or name.startswith('esn_out') or name.startswith('cms_out')) and (name.endswith('.tar.gz') or name.endswith('.tar'))


# --- Function: _validate_cnb_filename ---
# Purpose: Basic filename pattern check for CNB tar archives
# Info: returns bool used by upload validation UI
def _validate_cnb_filename(name: str) -> bool:
    return (name.startswith('cnb_in_out') or name.startswith('cnb_out')) and (name.endswith('.tar.gz') or name.endswith('.tar'))

# --- Function: _validate_ccms_filename ---
# Purpose: Basic filename pattern check for CCMS tar archives
def _validate_psv_filename(name: str) -> bool:
    return (name.endswith('.psv'))


# --- Function: _save_uploaded ---
# Purpose: Save an uploaded streamlit UploadedFile to the destination folder
# Info: replaces existing file with the same name; returns saved Path
def _save_uploaded(uploaded, dest_folder: Path) -> Path:
    """Save uploaded file to dest_folder, replacing existing file with same name."""
    dest_folder.mkdir(parents=True, exist_ok=True)
    dest = dest_folder / uploaded.name
    # write and replace if exists (this enforces replacement behavior)
    with open(dest, 'wb') as f:
        f.write(uploaded.getbuffer())
    return dest


def safe_replace(src: Path, dst: Path):
    """Replace dst with src atomically (cross-platform)."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    if sys.platform.startswith('win'):
        # Windows: use replace which overwrites
        src.replace(dst)
    else:
        # POSIX: use os.replace via shutil.move
        shutil.move(str(src), str(dst))




