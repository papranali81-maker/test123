import streamlit as st
from pathlib import Path
import utility as util


# ROOT Path
ROOT = Path(__file__).resolve().parent

# Function to load external CSS
def local_css(file_name):
    with open(file_name) as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Load style.css
local_css("style.css")

# Image of RBC
image_path = "rbc.png"

st.set_page_config(layout='wide', page_title='LGD Automation')

# initialize mode in session_state
if 'mode' not in st.session_state:
    st.session_state['mode'] = 'Welcome'


# Sidebar (left)
with st.sidebar:
    st.image(image_path, width="content")
    # st.markdown('### Refresh')
    if st.button('Home', use_container_width=True):
        # use utility to reset session (will set mode to Welcome)
        util.reset_session()

    st.markdown('---')
    st.header('Select Module', text_alignment="center")
    if st.button('Regression Report', use_container_width=True):
        st.session_state['mode'] = 'Regression Report'
    if st.button('Consolidated Report', use_container_width=True):
        st.session_state['mode'] = 'Consolidated Report'
    if st.button('Custom Join Report', use_container_width=True):
        st.session_state['mode'] = 'Custom Join Report'
    if st.button('File Compare Report', use_container_width=True):
        st.session_state['mode'] = 'File Compare Report'
    if st.button('File Analyzer', use_container_width=True):
        st.session_state['mode'] = 'File Analyzer'
    if st.button('PSV File Modifier', use_container_width=True):
        st.session_state['mode'] = 'PSV File Modifier'

# Main content area: center the welcome page visually
cols = st.columns([1, 3, 1])
main = cols[1]

mode = st.session_state.get('mode', 'Welcome')

if mode == 'Welcome':
    main.markdown('### LGD UAT Automation Solution', text_alignment="center")
    main.markdown("### Welcome All !", text_alignment="center")
    main.write(
        "The LGD Automation App is a streamlit-based tool that automates the extraction, joining, filtering, "
        "and reporting of PSV files from nested tar archives. It supports data streams from CCMS, CMS, and CNB modules, "
        "and generates reports that make it easier to analyze and test data values as required.")

    main.markdown('---')
    main.markdown('### Core Functions', text_alignment="center")
    main.markdown(
        '- Streamlit-based Processing: Handles large and continuous data flows from CCMS, CMS, and CNB modules efficiently.\n'
        '- Archive Handling: Automatically extracts PSV files from nested tar archives, reducing manual effort.\n'
        '- PSV File Operations: Joins, Filters, Transforms and Analyze pipe-separated values into structured outputs.\n'
        '- Report generation: Creates clear reports tailored for data analysis and testing needs.'
    )

elif mode == 'Regression Report':
    # delegate to regression generator view
    try:
        import regression_generator as rg
        rg.view()
    except Exception as e:
        st.error(f'Failed to load Regression Report module: {e}')

elif mode == 'Consolidated Report':
    try:
        import consolidated_generator as cg
        cg.view()
    except Exception as e:
        st.error(f'Failed to load Consolidated Report module: {e}')

elif mode == 'Custom Join Report':
    try:
        import custom_generator as cu
        cu.view()
    except Exception as e:
        st.error(f'Failed to load Custom Join Report module: {e}')

elif mode == 'File Compare Report':
    try:
        import file_compare_generator as fc
        fc.view()
    except Exception as e:
        st.error(f'Failed to load File Compare Report module: {e}')

elif mode == 'File Analyzer':
    try:
        import file_analyzer as fanz
        fanz.view()
    except Exception as e:
        st.error(f'Failed to load File Analyzer module: {e}')

elif mode == 'PSV File Modifier':
    try:
        import psv_modifier as psvm
        psvm.view()
    except Exception as e:
        st.error(f'Failed to load PSV File Modifier module: {e}')
