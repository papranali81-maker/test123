from pathlib import Path
import streamlit as st
import tarfile
import pandas as pd
from typing import List
import shutil

from utility import _ensure_dirs, _recent_files, _validate_filename, _save_uploaded
# Use canonical PSV readers from regression_generator to keep behavior consistent
from regression_generator import (
    read_psv_preserve_shape,
    _read_psv_skip_meta,
)
import streamlit.components.v1 as components

# --- Compatibility shim removed ---
# A previous version of this file included a small compatibility shim that
# imported `numba` and provided a `numba.generated_jit` alias for older
# versions of pandas_profiling / ydata_profiling that expected that name.
# The project does not use Numba directly and the shim created an import
# path to an optional dependency. Removing it keeps the codebase simpler.
# If you need to support an environment where pandas_profiling raises an
# AttributeError about `numba.generated_jit`, reintroduce a minimal shim
# or upgrade the profiling package.

# Import profiling libraries defensively: if unavailable or incompatible, keep None and show UI message
ProfileReport = None
st_profile_report = None
_profile_import_error = None
try:
    from pandas_profiling import ProfileReport  # type: ignore
except Exception as e:
    ProfileReport = None
    _profile_import_error = e

try:
    from streamlit_pandas_profiling import st_profile_report  # type: ignore
except Exception as e:
    st_profile_report = None
    if _profile_import_error is None:
        _profile_import_error = e

# ==========================================================
# Base directory (works even if you run from elsewhere)
# ==========================================================

ROOT = Path(__file__).resolve().parent
DATA_ROOT = ROOT / 'data' / 'file_analyzer'
UPLOADED_FOLDER = DATA_ROOT / 'Uploaded_files'
EXTRACTED_FOLDER = DATA_ROOT / 'Extracted_psv_files'
REPORTS_ROOT = ROOT / 'reports' / 'file_analyzer'
DATA_ROOT.mkdir(parents=True, exist_ok=True)
UPLOADED_FOLDER.mkdir(parents=True, exist_ok=True)
EXTRACTED_FOLDER.mkdir(parents=True, exist_ok=True)
REPORTS_ROOT.mkdir(parents=True, exist_ok=True)

# --- Module-level helpers (make them importable/testable) ---
def _clear_dir(path: Path):
    if path.exists():
        for p in path.iterdir():
            if p.is_dir():
                shutil.rmtree(p)
            else:
                p.unlink()
    else:
        path.mkdir(parents=True, exist_ok=True)


def _extract_psvs_from_tar(tar_path: Path, dest_dir: Path):
    """Extract .psv files from a (possibly nested) tar archive into dest_dir.
    This will clear dest_dir first.
    """
    _clear_dir(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)

    def _handle_tarfile_obj(tar_obj, base_dest: Path):
        for member in tar_obj.getmembers():
            if member.isfile():
                name = member.name or ''
                lname = name.lower()
                try:
                    f = tar_obj.extractfile(member)
                except Exception:
                    f = None
                if f is None:
                    continue
                if lname.endswith('.psv'):
                    target = base_dest / Path(name).name
                    with open(target, 'wb') as out:
                        out.write(f.read())
                elif lname.endswith(('.tar', '.tar.gz', '.tgz', '.gz')):
                    import tempfile as _tmp
                    tmpf = _tmp.NamedTemporaryFile(delete=False)
                    try:
                        tmpf.write(f.read())
                        tmpf.flush()
                        tmpf.close()
                        try:
                            with tarfile.open(tmpf.name, 'r:*') as inner_tar:
                                _handle_tarfile_obj(inner_tar, base_dest)
                        except Exception:
                            pass
                    finally:
                        try:
                            Path(tmpf.name).unlink()
                        except Exception:
                            pass

    with tarfile.open(tar_path, 'r:*') as tf:
        _handle_tarfile_obj(tf, dest_dir)


def _list_psvs(p: Path) -> List[str]:
    if not p.exists():
        return []
    files = [f.name for f in sorted(p.iterdir()) if f.is_file() and f.name.lower().endswith('.psv')]
    return files


def _recent_other_files(folder: Path, extensions: List[str], limit: int = 5) -> List[str]:
    """Return recent files from folder matching extensions (extensions items without leading dot)."""
    if not folder.exists():
        return []
    pats = []
    exts = tuple(['.' + e.lower().lstrip('.') for e in extensions])
    files = [p for p in sorted(folder.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True) if p.is_file() and p.suffix.lower() in exts]
    return [p.name for p in files[:limit]]


def load_psv_for_display(path: Path) -> pd.DataFrame:
    """Load a PSV while handling common preamble patterns:
    - Skips leading lines until the first '|' delimiter.
    - If the first '|' line is a NoOfRecord metadata row or appears numeric, promote the next line as header.
    - Returns a DataFrame with string values and no metadata columns.
    """
    text = path.read_text(encoding='utf-8', errors='replace')
    lines = [ln for ln in text.splitlines()]
    # find first line containing '|'
    start = 0
    for i, ln in enumerate(lines):
        if '|' in ln:
            start = i
            break
    content_lines = lines[start:]
    if not content_lines:
        return pd.DataFrame()

    # If there is at least two lines, inspect first and second to decide header
    header_offset = 0
    if len(content_lines) >= 2:
        first = content_lines[0].split('|')
        second = content_lines[1].split('|')

        def is_numeric_token(t: str) -> bool:
            t = t.strip().replace(',', '')
            if t == '':
                return False
            try:
                float(t)
                return True
            except Exception:
                return False

        first_join = ' '.join(first).lower()
        # If first row is NoOfRecord metadata, use second line as header
        if 'noofrecord' in first_join or 'businessdate' in first_join:
            header_offset = 1
        else:
            # if first line tokens are mostly numeric and second line tokens look like headers (non-numeric), promote second
            if all(is_numeric_token(tok) for tok in first) and any(not is_numeric_token(tok) for tok in second):
                header_offset = 1

    from io import StringIO
    csv_text = '\n'.join(content_lines)
    try:
        df = pd.read_csv(StringIO(csv_text), sep='|', engine='python', header=header_offset, dtype=str, keep_default_na=False)
    except Exception:
        # fallback to safe reader
        df = read_psv_preserve_shape(path)
    # Normalize column names and drop unnamed columns
    df.columns = [str(c).strip() for c in df.columns]
    df = df.loc[:, [c for c in df.columns if c and not str(c).lower().startswith('unnamed')]]
    # Drop any NoOfRecord columns
    df = df.drop(columns=[c for c in df.columns if ('noofrecord' in c.replace('_','').lower()) or ('businessdate' in c.replace('_','').lower())], errors='ignore')
    # Ensure string values
    df = df.fillna('').astype(str)
    return df

# --- Streamlit app code ---
def _reset_filecompare_state():
    """Reset Streamlit session state items related to regression generation so the user can start fresh.
    Note: do NOT set file_uploader-backed keys here (Streamlit errors if you set them). Only reset simple flags and select keys.
    """
    keys_defaults = {
        'file_report_generation': False,
        'folder1_select': '',
        'folder2_select': '',
        'folder1_verified': '',
        'folder2_verified': '',

    }
    for k, v in keys_defaults.items():
        st.session_state[k] = v

def view():
    # Ensure required folders(uploads, reports) exist on Root
    list_of_dirs = [DATA_ROOT, UPLOADED_FOLDER, EXTRACTED_FOLDER, REPORTS_ROOT]
    _ensure_dirs(list_of_dirs)

    st.markdown("# LGD UAT Automation Solution", text_alignment="center")
    st.title('File Analyzer and Insight', text_alignment="center")
    st.caption('Upload or Select TAR File or Excel/CSV file for Data Insights', text_alignment="center")


    # Refresh button for regression page (top-right of CCMS section)
    if st.button('Refresh', key='refresh_top'):
        _reset_filecompare_state()
        rerun = getattr(st, 'experimental_rerun', None)
        if callable(rerun):
            try:
                rerun()
            except Exception:
                pass

    # Initialize session keys used to remember verified status and file identity
    if 'file_report_generation' not in st.session_state:
        st.session_state['file_report_generation'] = False


    # Support both TAR archives and direct Excel/CSV uploads. Show recent TAR and recent Excel files.
    recent_tars = _recent_files(UPLOADED_FOLDER)
    recent_excels = _recent_other_files(UPLOADED_FOLDER, ['xls', 'xlsx', 'csv'])
    combined_recent = []
    # keep ordering: tars first then excels
    for name in recent_tars:
        combined_recent.append(name)
    for name in recent_excels:
        if name not in combined_recent:
            combined_recent.append(name)

    folder1_sel = st.selectbox('Select or Upload File (TAR or Excel)', options=[''] + combined_recent, key='folder1_select')
    folder1_upload = st.file_uploader('Or Upload File1 (TAR/GZ/XLS/XLSX/CSV)', type=['tar', 'gz', 'xls', 'xlsx', 'csv'], key='folder1_upload')
    folder1_path = None
    if folder1_upload is not None:
        # Allow Excel files without TAR filename validation; TARs still validated by existing logic
        name = folder1_upload.name
        suffix = Path(name).suffix.lower()
        if suffix in ('.xls', '.xlsx', '.csv'):
            folder1_path = _save_uploaded(folder1_upload, UPLOADED_FOLDER)
            st.success(f'Uploaded Excel/CSV to {folder1_path}')
            # Auto-verify Excel/CSV uploads so user can immediately select the uploaded file
            try:
                st.session_state['file_report_generation'] = True
                st.session_state['folder1_verified'] = str(folder1_path)
                # Pre-select the uploaded file in the PSV selectbox
                st.session_state['psv1_select'] = Path(folder1_path).name
                # Also set the folder1 select box value so folder1_path persists across reruns
                st.session_state['folder1_select'] = Path(folder1_path).name
                # Trigger a rerun so the selectboxes update immediately
                rerun = getattr(st, 'experimental_rerun', None)
                if callable(rerun):
                    try:
                        rerun()
                    except Exception:
                        pass
            except Exception:
                pass
        else:
            if not _validate_filename(name):
                st.error("Please upload a supported TAR file named like 'lgd_ccms_in_out_{timestamp}.tar.gz' or similar, or upload an Excel/CSV file.")
            else:
                folder1_path = _save_uploaded(folder1_upload, UPLOADED_FOLDER)
                st.success(f'Uploaded to {folder1_path}')
                try:
                    st.session_state['folder1_select'] = Path(folder1_path).name
                except Exception:
                    pass
    elif folder1_sel:
        # when a recent selection is used, set folder1_path so verification/extraction uses it
        folder1_path = UPLOADED_FOLDER / folder1_sel
        # If the user selected a recent Excel/CSV file, auto-verify it so the PSV selectbox is populated
        try:
            if folder1_path.suffix.lower() in ('.xls', '.xlsx', '.csv'):
                st.session_state['file_report_generation'] = True
                st.session_state['folder1_verified'] = str(folder1_path)
                # Pre-select the selected recent file in the PSV selectbox
                st.session_state['psv1_select'] = folder1_path.name
                # Trigger a rerun so the selectboxes update immediately
                rerun = getattr(st, 'experimental_rerun', None)
                if callable(rerun):
                    try:
                        rerun()
                    except Exception:
                        pass
        except Exception:
            pass


    # Keep verification only while selected/uploaded files remain unchanged
    current_folder1 = str(folder1_path) if folder1_path is not None else ''
    # If files changed since last verification, clear the verified flag
    if st.session_state.get('folder1_verified', '') != current_folder1:
        # Only clear the generation flag if the stored verification does not match current selection
        st.session_state['file_report_generation'] = False

    if st.session_state.get('file_report_generation') and st.session_state.get(
            'folder1_verified') == current_folder1:
        st.success('Files Verified')
    else:
        if folder1_path:
            col1, col2, col3, col4, col5, col6, col7, col8, col9 = st.columns(9)
            with col5:
                if st.button('Upload File and Verify'):
                    st.session_state['file_report_generation'] = True
                    st.session_state['folder1_verified'] = current_folder1
                    st.success('Files Verified')
        else:
            col1, col2, col3, col4, col5, col6, col7, col8, col9 = st.columns(9)
            with col5:
                st.button('Upload File and Verify ', disabled=True)

    st.markdown('---')

    # If verified, extract .psv files into extracted folders (calls module-level helpers)
    if st.session_state.get('file_report_generation'):
        if folder1_path:
            pth = Path(folder1_path)
            if pth.suffix.lower() in ('.xls', '.xlsx', '.csv'):
                # Excel/CSV: no extraction required; ensure Extracted folder is cleared so only this file is shown
                try:
                    _clear_dir(EXTRACTED_FOLDER)
                except Exception:
                    pass
            else:
                try:
                    _extract_psvs_from_tar(pth, EXTRACTED_FOLDER)
                except Exception as e:
                    st.error(f'Error extracting folder1 archive: {e}')


    # Only show extract select boxes after verification
    extracted1 = []
    if st.session_state.get('file_report_generation'):
        # If an Excel/CSV was uploaded/selected, show only that file in the select list.
        if folder1_path and Path(folder1_path).suffix.lower() in ('.xls', '.xlsx', '.csv'):
            extracted1 = [Path(folder1_path).name]
        else:
            extracted1 = _list_psvs(EXTRACTED_FOLDER)

    st.write('### Select PSV files to Analyze and Insight')

    psv1 = ''
    # If a single Excel/CSV was uploaded/selected, auto-select it so the user sees the choice immediately
    if st.session_state.get('file_report_generation') and extracted1 and len(extracted1) == 1:
        try:
            single = extracted1[0]
            if Path(single).suffix.lower() in ('.xls', '.xlsx', '.csv'):
                psv1 = single
                st.info(f'Selected uploaded file: {psv1}')
        except Exception:
            pass

    # Ensure the PSV select session key points to a valid available file so the selectbox shows a selection
    if st.session_state.get('file_report_generation') and extracted1 and not psv1:
        try:
            cur_psv = st.session_state.get('psv1_select', None)
            opts = [''] + extracted1
            if cur_psv is None or cur_psv not in opts:
                # pre-select the first real file (not the empty placeholder)
                st.session_state['psv1_select'] = extracted1[0]
        except Exception:
            pass

    if st.session_state.get('file_report_generation'):
        if extracted1:
            # if we already auto-selected psv1 above, just display selectbox with that selection
            if psv1:
                opts = [''] + extracted1
                try:
                    idx = opts.index(psv1)
                except Exception:
                    idx = 0
                psv1 = st.selectbox('Select File from Folder ', options=opts, index=idx, key='psv1_select')
            else:
                opts = [''] + extracted1
                # ensure the session state's selection exists in opts
                sel = st.session_state.get('psv1_select', None)
                try:
                    if sel not in opts:
                        sel = extracted1[0]
                        st.session_state['psv1_select'] = sel
                    idx = opts.index(sel)
                except Exception:
                    idx = 0
                    sel = opts[0]
                    st.session_state['psv1_select'] = sel
                psv1 = st.selectbox('Select File from Folder ', options=opts, index=idx, key='psv1_select')
        else:
            st.info('No PSV files found in Folder 1 after extraction. Upload and Verify first.')
    else:
        st.info('Select or upload both TAR files and click "Upload File and Verify" to extract PSV files.')


    df1 = None

    if psv1:
        # Determine whether selected file is an extracted PSV or an uploaded Excel/CSV
        if folder1_path and Path(folder1_path).name == psv1 and Path(folder1_path).suffix.lower() in ('.xls', '.xlsx', '.csv'):
            p1 = Path(folder1_path)
            try:
                if p1.suffix.lower() == '.csv':
                    df1 = pd.read_csv(p1, dtype=str, keep_default_na=False, encoding='utf-8', engine='python')
                else:
                    # read_excel will auto-detect engine; if multiple sheets exist, load the first
                    df1 = pd.read_excel(p1, dtype=str)
                # Ensure string values and drop unnamed columns similar to PSV path
                df1.columns = [str(c).strip() for c in df1.columns]
                df1 = df1.loc[:, [c for c in df1.columns if c and not str(c).lower().startswith('unnamed')]]
                df1 = df1.fillna('').astype(str)
            except Exception as e:
                st.error(f'Failed to read uploaded Excel/CSV file: {e}')
        else:
            p1 = EXTRACTED_FOLDER / psv1
            if p1.exists():
                # Use centralized loader which handles NoOfRecord preambles and header promotion
                try:
                    df1 = load_psv_for_display(p1)
                except Exception:
                    # fallback in case of unexpected parsing issues
                    try:
                        df1 = _read_psv_skip_meta(p1)
                    except Exception:
                        df1 = read_psv_preserve_shape(p1)
        if df1 is not None:
            st.write(f'Loaded File : {psv1} — {df1.shape[0]} rows x {df1.shape[1]} cols')
            # Reset EDA flag when a different file is selected
            try:
                prev = st.session_state.get('psv1_eda_for', '')
                if prev != psv1:
                    st.session_state['psv1_eda'] = False
                    st.session_state['psv1_eda_for'] = psv1
            except Exception:
                st.session_state['psv1_eda'] = False
                st.session_state['psv1_eda_for'] = psv1

            # EDA Insight button: user must click to show dataframe and profiling
            col_a, col_b, col_c = st.columns([3,4,3])
            with col_b:
                if st.button('Exploratory Data Analysis (EDA) Insight', key=f'eda_button_{psv1}'):
                    st.session_state['psv1_eda'] = True

            # Inform user to click the EDA button
            if not st.session_state.get('psv1_eda', False):
                st.info('Click "EDA Insight" to view the loaded DataFrame and profiling report for the selected file.')


    # Profiling and DataFrame display (only shown after user clicks EDA Insight)
    st.subheader("*** Input Dataframe from PSV ***")
    # If df1 is not loaded or EDA not requested, show appropriate message
    if df1 is None:
        st.write("No dataframe loaded yet.")
    else:
        if not st.session_state.get('psv1_eda', False):
            st.info('EDA not requested. Click "EDA Insight" to view DataFrame and profiling for the selected file.')
        else:
            # Always (re)load the selected source when EDA is requested. Streamlit reruns reset local variables
            try:
                sel = st.session_state.get('psv1_select', '')
                # make sure sel is a non-empty string
                if not sel:
                    df1 = pd.DataFrame()
                else:
                    # If it's a PSV from extracted folder
                    if str(sel).lower().endswith('.psv'):
                        p1 = EXTRACTED_FOLDER / sel
                        if p1.exists():
                            # Try canonical loader then fallbacks
                            try:
                                df1 = load_psv_for_display(p1)
                            except Exception:
                                df1 = pd.DataFrame()

                            if df1 is None or (isinstance(df1, pd.DataFrame) and df1.empty):
                                try:
                                    df1 = _read_psv_skip_meta(p1)
                                except Exception:
                                    try:
                                        df1 = read_psv_preserve_shape(p1)
                                    except Exception:
                                        df1 = pd.DataFrame()
                        else:
                            df1 = pd.DataFrame()
                    else:
                        # Could be uploaded excel/csv present in UPLOADED_FOLDER
                        upath = UPLOADED_FOLDER / sel
                        if upath.exists() and upath.suffix.lower() in ('.xls', '.xlsx', '.csv'):
                            try:
                                if upath.suffix.lower() == '.csv':
                                    df1 = pd.read_csv(upath, dtype=str, keep_default_na=False, encoding='utf-8', engine='python')
                                else:
                                    df1 = pd.read_excel(upath, dtype=str)
                                df1.columns = [str(c).strip() for c in df1.columns]
                                df1 = df1.loc[:, [c for c in df1.columns if c and not str(c).lower().startswith('unnamed')]]
                                df1 = df1.fillna('').astype(str)
                            except Exception:
                                df1 = pd.DataFrame()
                        else:
                            df1 = pd.DataFrame()
            except Exception:
                df1 = pd.DataFrame()

            # If after all attempts the dataframe is empty, provide helpful debug info for TAR-derived PSVs
            if df1 is None or (isinstance(df1, pd.DataFrame) and df1.empty):
                try:
                    sel = st.session_state.get('psv1_select', '')
                    if sel and str(sel).lower().endswith('.psv'):
                        p1 = EXTRACTED_FOLDER / sel
                        if p1.exists():
                            try:
                                stat = p1.stat()
                                size = stat.st_size
                                st.warning(f'PSV file found but produced empty DataFrame. Path: {p1} Size: {size} bytes')
                                # show a small snippet to help debug structure
                                text = p1.read_text(encoding='utf-8', errors='replace')
                                snippet = text[:2000]
                                st.text_area('First 2000 characters of PSV file (for debugging)', snippet, height=200)
                            except Exception as e:
                                st.warning(f'PSV file found but could not read for debug: {e}')
                        else:
                            st.warning(f'Expected PSV file at {p1} but file does not exist.')
                except Exception:
                    pass

            # Display only columns and their values. Avoid showing DataFrame index numbers.
            if df1 is None or (isinstance(df1, pd.DataFrame) and df1.empty):
                st.info('Loaded dataframe is empty.')
            else:
                # Use a scrollable dataframe display and hide the index for a clean look.
                # Calculate a height so approximately 10 rows are visible (row height estimate ~28px)
                nrows = min(len(df1), 10)
                # header + padding estimate added
                height = max(200, int(nrows * 28) + 80)
                try:
                    # Render the DataFrame as an HTML table inside a fixed-height scrollable div
                    # to ensure the table area has its own scrollbar and the index is not shown.
                    df_html = df1.to_html(index=False, classes='dataframe', border=0)
                    # Basic dark-theme friendly table styling; adjust colors as needed
                    style = f"""
                    <style>
                    .dataframe {{border-collapse: collapse; width: 100%;}}
                    .dataframe th, .dataframe td {{padding: 6px 8px; border-bottom: 1px solid rgba(255,255,255,0.06); color: #e6e6e6;}}
                    .dataframe thead th {{position: sticky; top: 0; background: rgba(0,0,0,0.6); z-index: 2;}}
                    </style>
                    """
                    html = f"{style}<div style='height:{height}px; overflow:auto;'>{df_html}</div>"
                    components.html(html, height=height, scrolling=True)
                except Exception:
                    # Fallback: convert to records and render; Streamlit may show index in edge cases
                    records = df1.to_dict(orient='records')
                    st.table(records)
            st.markdown('---')

            # Only attempt to build a profile report if the profiling libraries are available
            if ProfileReport is None or st_profile_report is None:
                st.warning("Pandas profiling is not available in this environment. To enable it, install a compatible profiling package (for example: 'ydata-profiling' and 'streamlit-pandas-profiling'). Import error: {}".format(repr(_profile_import_error)))
            else:
                try:
                    with st.spinner('Generating profile report (may take a while)...'):
                        report_title = f'File Analyzer Report for {st.session_state.get("psv1_select", psv1)}'
                        pr = ProfileReport(df1, title=report_title, explorative=True)
                    st.subheader("*** Pandas Profiling Report ***")
                    st_profile_report(pr)
                except Exception as e:
                    st.error(f'Failed to generate profiling report: {e}')


    # End of view()