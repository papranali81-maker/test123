LGD UAT Automation Solution

A Streamlit-based application to automate extraction, parsing, simple validation and reporting of PSV files packaged inside (possibly nested) TAR archives. The app supports multiple modules (Regression, Consolidated, Custom Join, File Compare, File Analyzer) used in LGD UAT workflows.

This README explains the repository layout, how to run the app locally, module responsibilities, the on-disk data layout, the new PSV Modifier behavior (metadata preservation and replacement rules), testing helpers, and common troubleshooting steps.

Quick start
-----------
This project can be run on Windows (developer workstation) or on a Linux server such as RHEL 8.10 (Target Station). The steps below cover both environments.

Prerequisites (recommended):
- Python 3.10+ (the project was developed with Python 3.11)
- A virtual environment (venv)

A. Quick Windows (PowerShell) setup (dev machine)

```powershell
python -m venv .venv
.\.venv\Scripts\activate   # activate the venv in PowerShell
pip install -r requirements.txt
streamlit run main.py --server.port 8502
```

B. Quick RHEL 8.10 setup (server)

```bash
# From the repository root
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip setuptools wheel
pip install -r requirements.txt
streamlit run main.py
```

Repository layout (short)
-------------------------
- main.py — Streamlit entry point and sidebar navigation.
- utility.py — Shared helpers for recent files, uploads, directory creation, and filename validation.
- regression_generator.py — Canonical PSV readers and regression-report helpers.
- psv_modifier.py — New Streamlit page that modifies PSV files using an Excel mapping (details below).
- file_analyzer.py — PSV preview helpers including `load_psv_for_display` used across UI pages.
- data/ — Per-module data root (uploaded files and extracted PSV files).
- reports/ — Generated reports per module.


PSV Modifier: metadata preservation and replacement behavior
----------------------------------------------------------
The project includes a `PSV File Modifier` Streamlit view implemented in `psv_modifier.py`. Key points to know:

- Loading PSVs for modification
  - The app uses `load_psv_for_display(path: Path)` (from `file_analyzer.py`) as the primary reader for PSV files shown in the UI. This loader:
    - Skips any leading preamble lines until the first pipe-delimited row.
    - If the first pipe-delimited row looks like metadata (for example contains `NoOfRecord` or `BusinessDate`) it promotes the *second* pipe-delimited row as the header for the table display and replacement logic.
  - Defensive fallbacks are available (the code falls back to the canonical readers in `regression_generator.py` if needed).

- Replacement semantics (`apply_replacements` helper)
  - The replacement logic normalizes the reference key for matching: trimming whitespace and doing case-insensitive matching.
  - Excel mapping file format assumed:
    - Column 1: Reference key that matches a column in the PSV (e.g., an ID column).
    - Columns 2+: Target PSV columns whose values should be replaced when the reference key matches.
  - Only columns present in the PSV are modified; Excel target columns that don't exist in the PSV are skipped and generate a warning in the UI.
  - Excel cells that are empty are treated as "no replacement" (i.e., the PSV's original value is kept). If you prefer empty Excel cells to explicitly clear values in the PSV, this can be adjusted — see notes below.

- Writing modified PSV files (preamble / metadata preservation)
  - When a PSV is modified the app writes the modified file using `write_psv_with_preamble(original_path, df, out_path)` which:
    - Preserves any preamble lines that come before the first pipe-delimited row.
    - If the first pipe-row is a metadata line (for example `NoOfRecord|100` or `BusinessDate|2026-02-17`) that metadata line is preserved exactly above the header in the output file.
    - Reuses the original header line if its tokens match the DataFrame columns (ignoring case/whitespace), otherwise writes a header generated from the DataFrame's columns.
    - Writes rows using '|' as the separator so the output remains a valid PSV with the same structure and preamble metadata preserved.

- Files and locations
  - Uploaded original PSV files are stored under `data/psv_modifier/Uploaded_files/Original_File/`.
  - Uploaded Excel replacement files are stored under `data/psv_modifier/Uploaded_files/Replace_File/`.
  - Modified PSVs are written to `reports/psv_modifier/` with filenames like `Modified_<OriginalName>_YYYYmmdd_HHMMSS.psv`.

Testing (unit + end-to-end)
---------------------------
A focused test suite for the PSV modifier has been added to `support/test_psv_modifier.py` and verifies:
- Normalized matching behavior and application of replacements.
- Preservation of preamble metadata lines like `NoOfRecord|...` and `BusinessDate|...` when writing the modified PSV.

To run only the PSV modifier tests (recommended when developing or changing modifier logic):

```powershell
# from repo root (PowerShell)
python -m pip install pytest
python -m pytest -q support/test_psv_modifier.py
```

To run the entire test suite (may include other integration tests that require additional environment setup):

```powershell
python -m pytest -q
```

Notes and configuration
-----------------------
- If you want empty Excel cells to explicitly clear PSV values, change the replacement lambda in `apply_replacements` to accept empty strings as valid replacements.
- Matching rules are implemented with trimming + case-insensitive equality. If you need fuzzy matching or other normalization rules (e.g., stripping leading zeros), implement a normalization helper and pass it through the `apply_replacements` function.

Troubleshooting
---------------
- If the Streamlit UI does not show uploads or the download button appears disabled, ensure the `data/psv_modifier/Uploaded_files/` and `reports/psv_modifier/` directories are writable.
- For profiling features in `file_analyzer`, optional packages like `ydata-profiling` may be required. The modifier and preamble-preserving logic do not depend on the profiling packages.

Developer notes
---------------
- The PSV modifier helpers (`apply_replacements`, `write_psv_with_preamble`) are implemented as small, testable functions so they can be reused in scripts or unit tests.
- The repository still exposes canonical PSV readers in `regression_generator.py` (e.g., `_read_psv_skip_meta`, `read_psv_preserve_shape`) used by other modules.

If you'd like, I can add a small demo script under `support/` that performs a sample modify run (creates a temporary PSV with `NoOfRecord`, an Excel replacement, runs the modify code, and prints the result) so you can manually inspect the before/after content quickly.

License / authorship
--------------------
(keep existing project license / attribution here)

----

If you want any wording changed or additional commands/examples added to the README (for example a short example showing the exact structure of the Excel replacement file), tell me which example you'd like and I'll add it.
