from pathlib import Path
import streamlit as st
import tempfile
import tarfile
import zipfile
import pandas as pd
from datetime import datetime
from typing import List, Optional, Tuple, Dict, Callable
import shutil
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
import re
from utility import _ensure_dirs, _recent_files, _validate_filename,  _save_uploaded
# Use canonical PSV readers from regression_generator to keep behavior consistent
from regression_generator import (
    read_psv_preserve_shape,
    _find_facility_header_line,
    _norm_col,
    read_facility_psv_smart,
    _read_psv_skip_meta,
)


# ==========================================================
# Base directory (works even if you run from elsewhere)
# ==========================================================

ROOT = Path(__file__).resolve().parent
DATA_ROOT = ROOT / 'data' / 'file_compare_generator'
UPLOADED_FOLDER1 = DATA_ROOT / 'Uploaded_files' / 'Folder_1'
UPLOADED_FOLDER2 = DATA_ROOT / 'Uploaded_files' / 'Folder_2'
EXTRACTED_FOLDER1 = DATA_ROOT / 'Extracted_psv_files'/ 'Folder_1'
EXTRACTED_FOLDER2 = DATA_ROOT / 'Extracted_psv_files'/ 'Folder_2'
REPORTS_ROOT = ROOT / 'reports' / 'file_compare_generator'
DATA_ROOT.mkdir(parents=True, exist_ok=True)
UPLOADED_FOLDER1.mkdir(parents=True, exist_ok=True)
UPLOADED_FOLDER2.mkdir(parents=True, exist_ok=True)
EXTRACTED_FOLDER1.mkdir(parents=True, exist_ok=True)
EXTRACTED_FOLDER2.mkdir(parents=True, exist_ok=True)
REPORTS_ROOT.mkdir(parents=True, exist_ok=True)

# --- Module-level helpers (make them importable/testable) ---
def _clear_dir(path: Path):
    if path.exists():
        for p in path.iterdir():
            if p.is_dir():
                shutil.rmtree(p)
            else:
                p.unlink()
    else:
        path.mkdir(parents=True, exist_ok=True)


def _extract_psvs_from_tar(tar_path: Path, dest_dir: Path):
    """Extract .psv files from a (possibly nested) tar archive into dest_dir.
    This will clear dest_dir first.
    """
    _clear_dir(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)

    def _handle_tarfile_obj(tar_obj, base_dest: Path):
        for member in tar_obj.getmembers():
            if member.isfile():
                name = member.name or ''
                lname = name.lower()
                try:
                    f = tar_obj.extractfile(member)
                except Exception:
                    f = None
                if f is None:
                    continue
                if lname.endswith('.psv'):
                    target = base_dest / Path(name).name
                    with open(target, 'wb') as out:
                        out.write(f.read())
                elif lname.endswith(('.tar', '.tar.gz', '.tgz', '.gz')):
                    import tempfile as _tmp
                    tmpf = _tmp.NamedTemporaryFile(delete=False)
                    try:
                        tmpf.write(f.read())
                        tmpf.flush()
                        tmpf.close()
                        try:
                            with tarfile.open(tmpf.name, 'r:*') as inner_tar:
                                _handle_tarfile_obj(inner_tar, base_dest)
                        except Exception:
                            pass
                    finally:
                        try:
                            Path(tmpf.name).unlink()
                        except Exception:
                            pass

    with tarfile.open(tar_path, 'r:*') as tf:
        _handle_tarfile_obj(tf, dest_dir)


def _list_psvs(p: Path) -> List[str]:
    if not p.exists():
        return []
    files = [f.name for f in sorted(p.iterdir()) if f.is_file() and f.name.lower().endswith('.psv')]
    return files


# --- Streamlit app code ---
def _reset_filecompare_state():
    """Reset Streamlit session state items related to regression generation so the user can start fresh.
    Note: do NOT set file_uploader-backed keys here (Streamlit errors if you set them). Only reset simple flags and select keys.
    """
    keys_defaults = {
        'file_report_generation': False,
        'folder1_select': '',
        'folder2_select': '',
        'folder1_verified': '',
        'folder2_verified': '',

    }
    for k, v in keys_defaults.items():
        st.session_state[k] = v

def view():
    # Ensure required folders(uploads, reports) exist on Root
    list_of_dirs = [DATA_ROOT, UPLOADED_FOLDER1, UPLOADED_FOLDER2, EXTRACTED_FOLDER1, EXTRACTED_FOLDER2, REPORTS_ROOT]
    _ensure_dirs(list_of_dirs)

    st.markdown("# LGD UAT Automation Solution", text_alignment="center")
    st.title('File Compare Report Generator', text_alignment="center")
    st.caption('Upload or Select File1 & File2 TAR files to generate File Compare reports', text_alignment="center")

    # Refresh button for regression page (top-right of CCMS section)
    if st.button('Refresh', key='refresh_top'):
        _reset_filecompare_state()
        rerun = getattr(st, 'experimental_rerun', None)
        if callable(rerun):
            try:
                rerun()
            except Exception:
                pass

    # Initialize session keys used to remember verified status and file identity
    if 'file_report_generation' not in st.session_state:
        st.session_state['file_report_generation'] = False


    c1, c2 = st.columns(2)
    with c1:
        folder1_sel = st.selectbox('Select File1 TAR File', options=[''] + _recent_files(UPLOADED_FOLDER1), key='folder1_select')
        folder1_upload = st.file_uploader('Or Upload File1 TAR File', type=['tar', 'gz'], key='folder1_upload')
        folder1_path = None
        if folder1_upload is not None:
            if not _validate_filename(folder1_upload.name):
                st.error("Please upload 'lgd_ccms_in_out_{timestamp}.tar.gz' or 'esn_out_{timestamp}.tar.gz' or or 'cnb_in_out_{timestamp}.tar.gz'")
            else:
                folder1_path = _save_uploaded(folder1_upload, UPLOADED_FOLDER1)
                st.success(f'Uploaded to {folder1_path}')
        elif folder1_sel:
            # when a recent selection is used, set folder1_path so verification/extraction uses it
            folder1_path = UPLOADED_FOLDER1 / folder1_sel
    with c2:
        folder2_sel = st.selectbox('Select File2 TAR File', options=[''] + _recent_files(UPLOADED_FOLDER2), key='folder2_select')
        folder2_upload = st.file_uploader('Or Upload File2 TAR File', type=['tar', 'gz'], key='folder2_upload')
        folder2_path = None
        if folder2_upload is not None:
            if not _validate_filename(folder2_upload.name):
                st.error("Please upload 'lgd_ccms_in_out_{timestamp}.tar.gz' or 'esn_out_{timestamp}.tar.gz' or or 'cnb_in_out_{timestamp}.tar.gz'")
            else:
                folder2_path = _save_uploaded(folder2_upload, UPLOADED_FOLDER2)
                st.success(f'Uploaded to {folder2_path}')
        elif folder2_sel:
            folder2_path = UPLOADED_FOLDER2 / folder2_sel

    # Keep verification only while selected/uploaded files remain unchanged
    current_folder1 = str(folder1_path) if folder1_path is not None else ''
    current_folder2 = str(folder2_path) if folder2_path is not None else ''
    # If files changed since last verification, clear the verified flag
    if st.session_state.get('folder1_verified', '') != current_folder1 or st.session_state.get(
            'folder2_verified', '') != current_folder2:
        # Only clear the generation flag if the stored verification does not match current selection
        st.session_state['file_report_generation'] = False

    if st.session_state.get('file_report_generation') and st.session_state.get(
            'folder1_verified') == current_folder1 and st.session_state.get(
            'folder2_verified') == current_folder2:
        st.success('Both files verified')
    else:
        if folder1_path and folder2_path:
            col1, col2, col3, col4, col5, col6, col7, col8, col9 = st.columns(9)
            with col5:
                if st.button('Upload File and Verify'):
                    st.session_state['file_report_generation'] = True
                    st.session_state['folder1_verified'] = current_folder1
                    st.session_state['folder2_verified'] = current_folder2
                    st.success('Both files verified')
        else:
            col1, col2, col3, col4, col5, col6, col7, col8, col9 = st.columns(9)
            with col5:
                st.button('Upload File and Verify ', disabled=True)

    st.markdown('---')

    # If verified, extract .psv files into extracted folders (calls module-level helpers)
    if st.session_state.get('file_report_generation'):
        if folder1_path:
            try:
                _extract_psvs_from_tar(Path(folder1_path), EXTRACTED_FOLDER1)
            except Exception as e:
                st.error(f'Error extracting folder1 archive: {e}')
        if folder2_path:
            try:
                _extract_psvs_from_tar(Path(folder2_path), EXTRACTED_FOLDER2)
            except Exception as e:
                st.error(f'Error extracting folder2 archive: {e}')

    # Only show extract selectboxes after verification
    extracted1 = []
    extracted2 = []
    if st.session_state.get('file_report_generation'):
        extracted1 = _list_psvs(EXTRACTED_FOLDER1)
        extracted2 = _list_psvs(EXTRACTED_FOLDER2)

    st.write('### Select PSV files to compare (from extracted files)')
    col_a, col_b = st.columns(2)
    with col_a:
        psv1 = ''
        if st.session_state.get('file_report_generation'):
            if extracted1:
                psv1 = st.selectbox('Select File from Folder 1', options=[''] + extracted1, key='psv1_select')
            else:
                st.info('No PSV files found in Folder 1 after extraction. Upload and Verify first.')
        else:
            st.info('Select or upload both TAR files and click "Upload File and Verify" to extract PSV files.')
    with col_b:
        psv2 = ''
        if st.session_state.get('file_report_generation'):
            if extracted2:
                psv2 = st.selectbox('Select File from Folder 2', options=[''] + extracted2, key='psv2_select')
            else:
                st.info('No PSV files found in Folder 2 after extraction. Upload and Verify first.')
        else:
            st.info('Select or upload both TAR files and click "Upload File and Verify" to extract PSV files.')

    df1 = None
    df2 = None
    if psv1:
        p1 = EXTRACTED_FOLDER1 / psv1
        if p1.exists():
            # Use canonical reader from regression_generator.py
            df1 = read_psv_preserve_shape(p1)
            st.write(f'Loaded File 1: {psv1} — {df1.shape[0]} rows x {df1.shape[1]} cols')
    if psv2:
        p2 = EXTRACTED_FOLDER2 / psv2
        if p2.exists():
            df2 = read_psv_preserve_shape(p2)
            st.write(f'Loaded File 2: {psv2} — {df2.shape[0]} rows x {df2.shape[1]} cols')

    # Show Generate button when both selected
    if df1 is not None and df2 is not None:
        if st.button('Generate File Compare Report'):
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            out_path = REPORTS_ROOT / f'file_compare_report_{timestamp}.xlsx'
            # Write both dataframes side by side with 3 column gap
            gap = 3
            try:
                with pd.ExcelWriter(out_path, engine='openpyxl') as writer:
                    # Reserve two rows for titles and filenames, then write tables starting at startrow=2
                    startrow = 2
                    df1.to_excel(writer, sheet_name='File Compare', index=False, startrow=startrow, startcol=0)
                    startcol2 = max(1, df1.shape[1] + gap)
                    df2.to_excel(writer, sheet_name='File Compare', index=False, startrow=startrow, startcol=startcol2)

                # Open workbook to style and compare
                wb = load_workbook(out_path)
                ws = wb['File Compare']

                # Styling helpers
                center = Alignment(horizontal='center', vertical='center')
                thin = Side(border_style='thin', color='000000')
                border = Border(left=thin, right=thin, top=thin, bottom=thin)
                green = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
                yellow = PatternFill(start_color='FFEB9C', end_color='FFEB9C', fill_type='solid')

                # Write titles and filename rows (Excel rows are 1-based). Do not merge cells - keep bold only
                # Title row (row 1) - left table title at col 1, right table title at startcol2+1
                if df1.shape[1] > 0:
                    t1 = ws.cell(row=1, column=1)
                    t1.value = 'File1 Results'
                    t1.alignment = Alignment(horizontal='left', vertical='center')
                    t1.font = Font(bold=True)
                if df2.shape[1] > 0:
                    t2 = ws.cell(row=1, column=startcol2 + 1)
                    t2.value = 'File2 Results'
                    t2.alignment = Alignment(horizontal='left', vertical='center')
                    t2.font = Font(bold=True)

                # Filename row (row 2) - show the raw PSV filename (no braces)
                f1cell = ws.cell(row=2, column=1)
                f1cell.value = f'File 1 Name - {psv1} File' if psv1 else 'File 1 Name - '
                f1cell.alignment = Alignment(horizontal='left', vertical='center')
                f2cell = ws.cell(row=2, column=startcol2 + 1)
                f2cell.value = f'File 2 Name - {psv2} File' if psv2 else 'File 2 Name - '
                f2cell.alignment = Alignment(horizontal='left', vertical='center')

                # Determine ranges
                rows1 = df1.shape[0]
                cols1 = df1.shape[1]
                rows2 = df2.shape[0]
                cols2 = df2.shape[1]
                max_rows = max(rows1, rows2)

                # Data rows start at Excel row (startrow + 2)
                data_start_row = startrow + 2

                # Compare cell by cell and apply fills
                for i in range(0, max_rows):
                    r = data_start_row + i
                    for c in range(1, max(cols1, cols2) + 1):
                        cell1 = None
                        cell2 = None
                        if c <= cols1:
                            cell1 = ws.cell(row=r, column=c)
                        if c <= cols2:
                            cell2 = ws.cell(row=r, column=c + startcol2)
                        val1 = '' if (cell1 is None or cell1.value is None) else str(cell1.value).strip()
                        val2 = '' if (cell2 is None or cell2.value is None) else str(cell2.value).strip()
                        if val1 == val2:
                            if cell1 is not None:
                                cell1.fill = green
                                cell1.alignment = center
                                cell1.border = border
                            if cell2 is not None:
                                cell2.fill = green
                                cell2.alignment = center
                                cell2.border = border
                        else:
                            if cell1 is not None:
                                cell1.fill = yellow
                                cell1.alignment = center
                                cell1.border = border
                            if cell2 is not None:
                                cell2.fill = yellow
                                cell2.alignment = center
                                cell2.border = border

                # Ensure headers also have border and center (headers are at startrow + 1)
                header_row = startrow + 1
                for c in range(1, cols1 + 1):
                    h = ws.cell(row=header_row, column=c)
                    h.alignment = center
                    h.border = border
                for c in range(startcol2 + 1, startcol2 + cols2 + 1):
                    h = ws.cell(row=header_row, column=c)
                    h.alignment = center
                    h.border = border

                wb.save(out_path)
                st.success(f'File compare report generated: {out_path}')
                # Provide download link
                with open(out_path, 'rb') as f:
                    st.download_button('Download File Compare Report', data=f, file_name=out_path.name)
            except Exception as e:
                st.error(f'Failed to create report: {e}')
    else:
        st.info('Select one PSV file from each folder to enable report generation.')

    # End of view()
